#include <iostream>
#include <cmath>
using namespace std;

int main () {
    
     
    int x;
    
    
    while (cin >> x) {
        cout.setf(ios::fixed);
        cout.precision(6); 
    
        cout << x*x << " " << sqrt(x) << endl;
    }
}
