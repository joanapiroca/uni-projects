#include <iostream>
#include <cmath>
using namespace std;

int main () {
    
     
    double x;
    
    
    while (cin >> x) {
        cout.setf(ios::fixed);
        cout.precision(0); 
    
        cout << pow(x,2);
    
        cout.setf(ios::fixed);
        cout.precision(6); 
        
        cout<< " " << sqrt(x);
    }
}
