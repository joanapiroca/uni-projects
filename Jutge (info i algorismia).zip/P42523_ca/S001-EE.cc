#include <iostream>
#include <cmath>
using namespace std;

int mcd(int a, int b) {
    if (a%b == 0) return b;
    return mcd(b, a%b);
}
int main () {
    int a, b;
    cin >> a >> b;
    cout << mcd(a, b) << endl;
}
