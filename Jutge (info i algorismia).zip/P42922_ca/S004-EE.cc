#include <iostream>
using namespace std;

bool es_prim(int n, int b) {
    if(n==1) return true;
    if (n%b >= b/2 ) return false;
    return es_prim(n/10, b);
}

int main() {
    int n, b;
    while(cin >> n >> b) {
        cout << es_prim(n, b) << endl;
    }
}
