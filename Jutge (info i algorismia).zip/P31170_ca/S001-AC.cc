#include <iostream>
using namespace std;

int main()
{
    int a;
    cin >> a;
    
    int i;
    i = 1;
    while (i <= 10) {
        cout << a << "*" << i << " = " << (a*i) << endl;
        i = i + 1;
    }
}
