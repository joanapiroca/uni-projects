#include <iostream>
#include <vector>
#include <queue>
using namespace std;

using VE = vector<int>;
using VVE = vector<VE>;
using p = pair<int,int>;
using VP = vector<p>;
using VVP = vector<VP>;

//Sense dijkstra per què ens donaria el de cost mínim , no mínimes arestes.
//El faig amb amplada i acumulo costos

int INF = 1e9;
int n, m, inici;
VVP g;				 //guarda les arestes a g[x] , {l i y}
VP dist; 			//parades i longitud mínimes de inici al vèrtex i;
VE vist;			//marco per quins vèrtexs he passat;


//Parades i cost mínims per anar de inici a tots els altres vèrtexs

void f() {
	queue<pair<int, p>> q; //vèrtex, parades, longitud
	q.push({inici, {0,0}});
	vist[inici] = true;
	dist[inici] = {0,0};
	
	while(not q.empty()) {
		auto aux = q.front();
		q.pop();
		int x = aux.first;
		int par0 = aux.second.first;
		int lon0 = aux.second.second;
		
		
		for(auto a : g[x]) {	//passo pels veïns de x
			int lon = lon0 + a.first;
			int y = a.second;
			
			if(not vist[y] or (vist[y] and  dist[y].first >= par0+1 and dist[y].second > lon) ) {
				q.push({y, {par0 +1, lon}});
				dist[y].first = par0+1;
				dist[y].second = lon;
				vist[y] = true;
			}
		}
	} 
}
	


int main() {
	while(cin >> n >> m) {
		g = VVP(n);
		for(int i = 0; i < m; ++i) {
			int x, y, l;
			cin >> x >> y >> l;
			g[x].push_back({l,y});
			g[y].push_back({l,x});
		}
		cin >> inici;
		
		dist = VP(n, {INF,INF});
		vist = VE(n, false);
		f();
		
		
		for(int i = 0; i < n; ++i) {
			cout << i << ": ";
			if(vist[i]) cout << dist[i].first << " " << dist[i].second << endl;
			else cout << "no" << endl;
		}
		for(int i = 0; i < 10; ++i) cout << '-';
		cout << endl;
	}
}
