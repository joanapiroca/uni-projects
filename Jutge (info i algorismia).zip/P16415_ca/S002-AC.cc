#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

using VE = vector<int>;
using VC = vector<char>;
using ME = vector<VE>;
using VS = vector<string>;
using p = pair<int,int>;

int n, reines;
VE r, c, de, dd; //de = diagonal d'equerra a dreta, dd = diagonals de dreta a esquerra

//PERQUÈ NO FUNCIONA?????

void f(int i) {

	if(i == n) {
		++reines;
		return;
	}
	
	for(int j = 0; j < n; ++j) {
			
			if(not r[i] and not c[j] and not de[i-j+n-1] and not dd[i+j]) {		
				
				r[i] = true;
				c[j] = true;
				de[i-j+n-1] = true;
				dd[i+j] = true;
				f(i+1);
				
				r[i] = false;
				c[j] = false;
				de[i-j+n-1] = false;
				dd[i+j] = false;
				
			}
		
	}	
}


/*	
	for(int j = 0; j < n; ++j) {
		for(int k = 0; k < n; ++k) {
			if(not r[j] and not c[k] and not d[j-k+n-1]) {
				r[j] = true;
				c[k] = true;
				d[j-k+n-1] = true;
				f(i+1);
				
				r[j] = false;
				c[k] = false;
				d[j-k+n-1] = false;
			}
		}
	}
}
*/

int main() {
	//hi ha 2n-1 diagonals, totes les caselles d'una diagonal tenen el mateix índex i-j.
	cin >> n;
	r = VE(n, false);
	c = VE(n, false);
	de = VE(2*n - 1, false);
	dd = VE(2*n - 1, false);
	
	reines = 0;
	f(0);
	cout << reines << endl;
}
