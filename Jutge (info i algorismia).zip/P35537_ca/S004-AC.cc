#include <iostream>
#include <cmath>
using namespace std;

bool es_creixent(int n) {
    if (n==0) return true;
    if ((n/10)%10 > n%10) return false;
    else if (es_creixent(n/10));
}
int main () {
    int n;
    cin >> n;
    cout << es_creixent(n) << endl;
}
