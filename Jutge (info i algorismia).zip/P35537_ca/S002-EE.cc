#include <iostream>
#include <cmath>
using namespace std;

bool es_creixent(int n) {
    
    if (es_creixent(n/10) and ((n/10)%10 <= (n/10))) return true;
}
int main () {
    int n;
    cin >> n;
    cout << es_creixent(n) << endl;
}
