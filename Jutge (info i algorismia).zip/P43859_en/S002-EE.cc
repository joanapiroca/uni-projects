#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

using VE = vector<int>;
using ME = vector<VE>;
using VS = vector<string>;
using p = pair<int,int>;
using VP = vector<p>;
using MP = vector<VP>;

ME F;
MP G;
int n, m;

int main() {
	while(cin >> n >> m) {
		int u, v, c;
		G = MP(n);
		F = ME(n, VE(m, 1e9));
		while(m--) {
			cin >> u >> v >> c;
			G[u].push_back({c,v});
			F[u][v] = c;
		}
		int x, y;
		cin >> x >> y;
		
		for ( int i = 0; i < n ; ++i) F [ i ][ i ] = 0;
		
		for ( int k = 0; k < n ; ++ k ) {
			for ( int i = 0; i < n ; ++ i ) {
				for ( int j = 0; j < n ; ++ j ){
					 F [ i ][ j ] = min ( F [ i ][ j ] , F [ i ][ k ] + F [ k ][ j ]);
				 }
			 }
		}
		if(F[x][y] == 1e9) cout << "no path from " << x << " to " << y;
		else cout << F[x][y];
		cout << endl;
	}
}
		
			
			
