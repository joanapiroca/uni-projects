#include <iostream>
#include <vector>
using namespace std;

typedef vector<string> Fila;
typedef vector<Fila> Matriu;

 int nombre_de_paraules(const Matriu& m, char c, int k) {
    int row = m.size();
    int col; //canvien prque m no es rectangular
    int cont = 0;
    
    for(int i = 0; i < row; ++i) {
        col = m[i].size();
        for(int j = 0; j < col; ++j) {
            if( m[i][j].size() >= k) {
                if(m[i][j][k] == c) ++cont;
            }
        }
    }  
    return cont;
 }



int main () {
    int c;
    char b;
    cin >> b >> c;
    Matriu a(2, Fila(2));
    for(int i = 0; i < 2; ++i) {
        for(int j = 0; j < 2; ++j) cin >> a[i][j];
     }  
     
    cout << nombre_de_paraules(a, b, c) << endl;
  
}