#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

using VE = vector<int>;
using ME = vector<VE>;
using VS = vector<string>;
using p = pair<int,int>;
using VP = vector<p>;
using MP = vector<VP>;

int x, y, ways;
VE cost, pare;
MP G;
int n, m;

void dijkstra() {
	cost = VE(n, 1e9);
	pare = VE(n, -1);
	ways = 1;
	priority_queue<p> q;
	cost[x] = 0;
	pare[x] = -2;
	q.push({0,x});
	
	//Fer-ho amb cua em garanteix que és el camí amb menys arestes (STEPS)
	while(not q.empty()) {
		p a = q.top();
		q.pop();
		int d = -a.first;
		int u = a.second;
		if(d == cost[u]) {
			if(u == y) return;
			
			for(int i = 0; i < (int)G[u].size(); ++i) {
				int c = G[u][i].first;
				int v = G[u][i].second;				
				int d2 = d+c;
				if(d2 <= cost[v]) {
					if(d2 == cost[v]) ++ways;
					else{
						cost[v] = d2;
						pare[v] = u;
						q.push({-d2, v});
					}
				}
			}
		}
	}
}
		
		
	
int main() {
	while(cin >> n >> m) {
		int u, v, c;
		G = MP(n);
		while(m--) {
			cin >> u >> v >> c;
			G[u].push_back({c,v});
		}
		cin >> x >> y;
		
		dijkstra();
		if(pare[y] == -1) cout << "no path from " << x << " to " << y;
		else cout << "cost " << cost[y] << ", " << ways << " way(s)";
		cout << endl;
		
		
	}
}
		
			
			
