#include <iostream>
#include <cmath>
using namespace std;

int main () {
    
    int a;
    cin >> a;
    
    int h = a / 3600;
    int m = a % 3600 / 60;
    int s = a % 60;
    
    cout << h << " " << m << " " << s << endl;    
}

