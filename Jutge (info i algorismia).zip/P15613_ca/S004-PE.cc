#include <iostream>
#include <cmath>
using namespace std;

int main () {
    
    int a;
    cin >> a;
   
    if ( 100 > a and a > 30 ) cout << "fa calor" << endl;
    else if (a >= 100 ) cout << "fa calor" << endl << "l'aigua bulliria" << endl;
    else if ( 0 < a and a < 10 ) cout << "fa fred" << endl;
    else if ( a <= 0 ) cout << " fa fred " << endl << "l'aigua es gelaria" << endl;
    else cout << "s'esta be" << endl;
    
}

