#include <iostream>
#include <vector>
using namespace std;

 vector<double> interseccio(const vector<double>& v1, const vector<double>& v2) {
     int i = 0, j = 0;
     vector<double> c;
     while (i < v1.size() and j < v2.size()) {
         if(v1[i] == v1[i-1]) ++i;
         if(v2[j] == v2[j-1]) ++j;
         
         if (v1[i] < v2[j]) ++i;
         if (v1[i] > v2[j]) ++j;
         if (v1[i] == v2[j]) {
             c.push_back(v1[i]);
             ++i;
             ++j;             
         }
     }
     return c;
}

int main () {
   
}
