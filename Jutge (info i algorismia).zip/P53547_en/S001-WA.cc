#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <algorithm>
using namespace std;

using VE = vector<int>;
using ME = vector<VE>;
using p = pair<int,int>;
using VC = vector<char>;
using MC = vector<VC>;

const VE df = {1,  1, -1, -1};
const VE dc = {-1, 1, -1,  1};

int n, m, P, N; //P = num de caselles, N = numero de bishops total
MC mapa;
ME vist; //Marco els vèrtexs vistos a cada component connexa per no tornar a passar-hi

//Conto el numero de vèrtexs de la component, calculo els bushops que hauria d'haver en tota la component si es repertís equitativament, si no coincideix amb els obispos que hi ha torno fals.
bool dfs(int x, int y) {
	int ver = 1; //Numero de vèrtexs de la component (ja tinc el vèrtex (x,y) com a vist);
	int bi = mapa[x][y]; //Numero de bishops en tota la component (N*ver/p ha de coincidir amb bi) (ja compto els bishops del vèrtex x,y)
	
	stack<p> s;
	vist[x][y] = true;
	s.push({x,y});
	while(not s.empty()) {
		int i0 = s.top().first;
		int j0 = s.top().second;
		s.pop();
		
		for(int k = 0; k < 4; ++k) {
			int i = i0 + df[k]; 
			int j = j0 + dc[k];
			
			if(i >= 0 and i < n and j >= 0 and j < m and mapa[i][j] != 'X' and not vist[i][j]) {
				++ver;
				bi = bi + mapa[i][j];
				vist[i][j] = true;
				s.push({i,j});
			}
		}
	}
	
	return ((N/P)*ver == bi);
			
}


bool components_okey() {
	for(int i = 0; i < n; ++i) {
		for(int j = 0; j < m; ++j) {
			if(not vist[i][j] and mapa[i][j] != 'X') {
				if(not dfs(i,j)) return false;
			}
		}
	}
	return true;
}

int main() {
	int t;
	int cont = 1;
	cin >> t;
	while(cont <= t) {
		cin >> n >> m;
		P = 0;
		N = 0;
		mapa = MC(n, VC(m));
		for(int i = 0; i < n; ++i) {
			for(int j = 0; j < m; ++j) {
				cin >> mapa[i][j];
				if(mapa[i][j] != 'X') {
					++P;
					N = N + mapa[i][j];
				}
			}
		}
		
		vist = ME(n, VE(m, false));
		cout << "Case " << cont << ": ";
		if(components_okey()) cout << "yes" << endl;
		else 				  cout << "no"  << endl;			
		++cont;				 
	}
}

