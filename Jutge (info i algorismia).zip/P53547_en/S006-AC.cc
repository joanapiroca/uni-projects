#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <algorithm>
using namespace std;

using VE = vector<int>;
using ME = vector<VE>;
using p = pair<int,int>;
using VS = vector<string>;
using MS = vector<VS>;

const VE df = {1,  1, -1, -1};
const VE dc = {-1, 1, -1,  1};

int n, m, P,N, suma, elements; 
MS mapa;
ME vist; //Marco els vèrtexs vistos a cada component connexa per no tornar a passar-hi

int valor(string s) {
    int mida = s.length();
    int val = s[0] - '0';
    for (int i = 1; i < mida; ++i) val = 10*val + int(s[i] - '0');
    return val;
}

//Conto el numero de vèrtexs de la component, calculo els bushops que hauria d'haver en tota la component si es repertís equitativament, si no coincideix amb els obispos que hi ha torno fals.
void dfs(int i, int j) {
	if(i >= 0 and i < n and j >= 0 and j < m and mapa[i][j] != "X" and not vist[i][j]) {
		++elements;
		suma += valor(mapa[i][j]);
		vist[i][j] = true;
		dfs(i+1,j+1);
		dfs(i+1,j-1);
		dfs(i-1,j+1);
		dfs(i-1,j-1);
	}		
}


bool components_okey() {
	for(int i = 0; i < n; ++i) {
		for(int j = 0; j < m; ++j) {
			if(not vist[i][j] and mapa[i][j] != "X") {
				elements = 0;
				suma = 0;
				dfs(i,j);
				if(suma%elements != 0) return false;
				if((N/P)*elements != suma) return false;		
			}
		}
	}
	return true;
}

int main() {
	int t;
	cin >> t;
	for(int k = 0; k < t; ++k) {
		cin >> n >> m;
		mapa = MS(n, VS(m));
		P = 0;
		N = 0;
		mapa = MS(n, VS(m));
		for(int i = 0; i < n; ++i) {
			for(int j = 0; j < m; ++j) {
				cin >> mapa[i][j];
				if(mapa[i][j] != "X") {
					++P;
					N += valor(mapa[i][j]);
				}
			}
		}
		
		//cout << "P,N, N/P:" << P <<"," << N << "," << N/P << endl;
		vist = ME(n, VE(m, false));
		cout << "Case " << k+1 << ": ";
		if(components_okey()) cout << "yes" << endl;
		else cout << "no"  << endl;			 
	}
}

