#include <iostream>
#include <cmath>
using namespace std;

char codificat(char c, int k) {
    if (c== '_') return ' ';
    if (c < 'a' or c > 'z') return c;
    
    return (c - 'a' + k)%26 + 'A';
}

int main() {
    char c;
    int k;
    while (cin >> k) {
        cin >> c;
        while ('c' != '.') {
            cout << codificat(c, k);
        }
    cout << endl;
    }
    
}
