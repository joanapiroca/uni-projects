#include <iostream>
using namespace std;

int main() {
   char a;
   int n = 0;
   while (cin >> a) {
       if(a == '(') ++n;
       if(a == ')') --n;
   }
   if (n == 0) cout << "si" << endl;
   else cout << "no" << endl;
}   