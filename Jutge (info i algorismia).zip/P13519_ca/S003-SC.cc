#include <iostream>
#include <vector>
#include <set>
#include <sstream>
using namespace std;

using VE = vector<int>;

int k, n;
VE dip, escullo;

void escriu() {
	cout << '{';
        bool primer = true;
        for (int i = 0; i < n; ++i) {
            if(escullo[i]){
                if(primer) primer = false;
                else cout << ", ";
                cout << i+1;
            }
        }
        cout << '}' << endl;
	return;
}


//Estic a la posició i, els partits escollits fins ara sumen "suma", "queda" és la suma de tots els partits més grans que i)
void f(int i, int suma, int queda, int minim) {
	if(suma + queda < k) return;
	if(suma == k) return escriu();
	if(suma + queda == k) {
		for(int j = i ; j < n; ++j) escullo[j] = true;
		return escriu();
	}
	
	if(suma > k) {
		//Cas que la coalisió és redundant
		if(suma - minim >= k) return;
		//No és redundant (i els de després de i no estàn escollits ja que el vector està inicialitzat a fals)
		return escriu();
	}	
	
	//if(i == n) return;
	
	escullo[i] = true;
	f(i+1, suma + dip[i], queda - dip[i], min(minim, dip[i]));
	escullo[i] = false;
	f(i+1, suma, queda - dip[i], minim);
}
	


int main() {
	while(cin >> k >> n) {
		dip = VE(n, 0);
		escullo = VE(n, false);
		for(int& x : dip) cin >> x;
		
		int resto = 0;
		for(int i = 0; i < n; ++i) resto += dip[i];
		
		f(0, 0, resto, 1e9);
		for(int i = 0; i < 10; ++i) cout << '-';
		cout << endl;
	}
}
