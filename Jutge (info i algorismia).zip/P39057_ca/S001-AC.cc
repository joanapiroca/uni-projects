#include <iostream>
#include <string>
#include <cmath>
using namespace std;

int main (){
    cout.setf(ios::fixed);
    cout.precision(6);
    
    int n;
    cin >> n;
    string a;
    
    
     
    while (cin >> a) {
        if (a == "rectangle") {
            double x, y;
            cin >> x;
            cin >> y;
            cout << (x * y) << endl;
        }
        if (a == "cercle") {
           double r; 
           cin >> r;
           cout << ( M_PI * r * r) << endl;
        }
    }

    
}
