#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;

//Està millorat del que el jutge m'accepta, perquè no funciona????

int s, n;
VE v;
VE tria;

void escriu() {
    for(int i=0; i < n; ++i) {
        if(tria[i]) cout << v[i] << ",";
    }
    cout << endl;
}


void f(int i, int sum) {
    if(sum == s) return escriu();
    if(sum > s) return;
    
    int res = 0;
    for(int j=i+1; j < n; ++j) res = res + v[j];
    if(sum + res < s) return;    
    if(i == n) return;
    
    tria[i] = 0;
    f(i+1, sum);
    tria[i] = 1;
    f(i+1, sum + v[i]);
}


int main() {
    cin >> s >> n;
    v = VE(n);
    tria = VE(n);
    for(int& x : v) cin >> x;
    f(0, 0);
}
