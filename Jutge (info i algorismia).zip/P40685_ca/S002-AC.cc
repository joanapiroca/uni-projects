#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;

//Està millorat del que el jutge m'accepta, perquè no funciona????

int s, n;
VE v;
VE tria;

bool ultim(int j) { 
    while(j < n) {
        if(tria[j] != 0) return false;
        ++j;
    }
    return true;
}

void escriu() {
    cout << "{";
    for(int i=0; i < n; ++i) {
        if(tria[i]) cout << v[i] << (ultim(i+1)? "" : "," );
    }
    cout << "}" << endl;
}


void f(int i, int sum) {
    if(i == n) {
        if(sum == s) return escriu();
        return;
    }
    
    
    tria[i] = 0;
    f(i+1, sum);
    tria[i] = 1;
    f(i+1, sum + v[i]);
}


int main() {
    cin >> s >> n;
    v = VE(n);
    tria = VE(n);
    for(int& x : v) cin >> x;
    f(0, 0);
}
