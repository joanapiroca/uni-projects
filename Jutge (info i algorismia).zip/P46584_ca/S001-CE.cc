#include <iostream>
#include <vector>
using namespace std;

vector<double> interseccio(const vector<double>& v1, const vector<double>& v2) {
    int max;
    if (v1[int(v1.size()) - 1] > v2[int(v2.size()) - 1]) max = v1[int(v1.size()) - 1];
    else max = v2[int(v2.size()) - 1];
    
    vector<bool> c(max + 1, false);
    
    int j = 0;
    int i = 0;
    
    while (i < int(v1.size()) and j < int(v2.size())) {
        if( v1[i] < v2[j]) ++i;
        if( v2[i] < v1[j]) ++j;
        if( v1[i] == v2[j] and c[ v1[i]] == false) c[(v1[i])] = true; 
    }
    
    vector<double> r;
    for(double i = 0; i < (double)c.size(); ++i) {
        if( c[i] == true) res.push_back(i);
    }
    return res;
}

int main () {
    vector<double> u(6);
    vector<double> v(4);
    
    for(int i = 0; i < 6; ++i) cin >> u[i];
    for(int i = 0; i < 4; ++i) cin >> v[i];
    
    for(int i = 0; i < 2; ++i) cout << interseccio(u, v)[i] << " ";
}
