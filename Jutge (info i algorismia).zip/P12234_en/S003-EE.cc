#include <iostream>
using namespace std;

int main() {
    int n;
    int c;
    int p;
    
    cin >> n >> c >> p;
    
    int max;
    int min; 
    max = c / p ;
    min = (c - ((n - 1) * (p - 1))) / p ;
    
    cout << min << " " << max << endl;
    
    int n1;
    int c1;
    int p1;
    
    cin >> n1 >> c1 >> p1;
    
    int max1;
    int min1; 
    max1 = c1 / p1 ;
    min1 = (c1 - ((n1 - 1) * (p1 - 1))) / p1 ;
    
    cout << min1 << " " << max1 << endl;
    
    
    int n2;
    int c2;
    int p2;
    
    cin >> n2 >> c2 >> p2;
    
    int max2;
    int min2; 
    max2 = c2 / p2 ;
    min2 = (c2 - ((n2 - 1) * (p2 - 1))) / p2 ;
    
    cout << min2 << " " << max2 << endl;
}

