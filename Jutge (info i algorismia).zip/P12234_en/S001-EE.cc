#include <iostream>
using namespace std;

int main() {
    int n;
    int c;
    int p;
    
    cin >> n >> c >> p;
    
    int max;
    int min; 
    max = c / p ;
    min = (c - ((n - 1) * (p - 1))) / p ;
    
    cout << min << " " << max << endl;
}

