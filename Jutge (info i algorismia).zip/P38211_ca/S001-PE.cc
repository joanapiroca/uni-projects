#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

using VE = vector<int>;
using VC = vector<char>;
using ME = vector<VE>;
using VS = vector<string>;
using p = pair<int,int>;

int n;
VE c, pos, de, dd; //de = diagonal d'equerra a dreta, dd = diagonals de dreta a esquerra
bool trobat = false;

void escriu() {
	if(not trobat) {
		for(int i = 0; i < n; ++i) {
			for(int j = 0; j < n; ++j) {
				if(pos[i] == j) cout << 'Q';
				else cout << '.';
			}
			cout << endl;
		}
		cout << endl;
		trobat = true;
	}
}

void f(int i) {
	if(trobat) return;
	if(i == n) return escriu();
	//cout << 'a';
	for(int j = 0; j < n; ++j) {
		//cout << 'b';
		if(not c[j] and not de[i-j+n-1] and not dd[i+j]) {	
			pos[i] = j;	
			c[j] = true;
			de[i-j+n-1] = true;
			dd[i+j] = true;
			f(i+1);
			
			c[j] = false;
			de[i-j+n-1] = false;
			dd[i+j] = false;
		}
	}
	//cout << 'c';
}



int main() {
	//hi ha 2n-1 diagonals, totes les caselles d'una diagonal tenen el mateix índex i-j.
	cin >> n;
	pos = VE(n);
	c = VE(n, false);
	de = VE(2*n - 1, false);
	dd = VE(2*n - 1, false);
	
	f(0);
	if(not trobat) cout << "NO SOLUTION" << endl;
}
