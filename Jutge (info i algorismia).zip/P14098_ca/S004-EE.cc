#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;


int n, t, x, y;
VE v;

bool ultim(int j) { 
    while(j < n) {
        if(v[j] != 0) return false;
        ++j;
    }
    return true;
}

void escriu() {
    cout << "{";
    for(int i = 0; i < n; ++i) {
        int j = 0;
        while(j < v[i]) {
            ++j;
            cout << i+1 << (j == v[i] and ultim(i+1)? "" : "," );
        }
    }
    cout << "}" << endl;
}

void f(int i, int sum) {        
    if(i == n-1) {
	  if(sum <= y and sum >= x) {
	      v[i] = sum;
          return escriu();
      }
    }
    if(x*(n-i) > sum) return;
    
    else {
      for(int j = x; j <= y; ++j) {
            v[i] = j;
            f(i+1, sum-j);
      }
    }
    
}
                  


int main() {
    cin >> n >> x >> y>> t;
    v = VE(n,0);
    if (t != 0) f(0, t);
}
