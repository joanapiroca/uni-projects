#include <vector>
#include <iostream>
using namespace std;

void ordena_per_insercio(vector<double>& v) {
    for(int i = 1; i < v.size() - 1; ++i) {
        int x = v[i];
        int j = i - 1;
        
        while(j >= 0 and x < v[j]) {
            v[j + 1] = v[j];
            --j;
        }
        v[j+1]= x;
    }
}

int main() {
   
}
