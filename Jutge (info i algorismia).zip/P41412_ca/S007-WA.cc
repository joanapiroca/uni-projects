#include <vector>
#include <iostream>
using namespace std;

void ordena_per_insercio(vector<double>& v) {
    for(int i = 1; i < (int)v.size(); ++i) {
        int x = v[i];
        int j = i;
        
        while(j > 0 and x < v[j - 1]) {
            v[j] = v[j - 1];
            --j;
        }
        v[j]= x;
    }
}

int main() {
   
}
