#include "Player.hh"


/**
 * Write the name of your player and save this file
 * with the same name and .cc extension.
 */
#define PLAYER_NAME jou3


struct PLAYER_NAME : public Player {

  /**
   * Factory: returns a new instance of this class.
   * Do not modify this function.
   */
  static Player* factory () {
    return new PLAYER_NAME;
  }

  /**
   * Types and attributes for your player can be defined here.
   */

 const vector<Dir> dirs = {Up,Down,Left,Right};

// Retorna la posició i direcció de la casella no buida més propera des de la posició (p).
// f, c indexades des de 0.
// Retorna -1 si no es pot arribar a cap tresor.

//com fer per veure si tinc dos coses a la mateixa distancia, i que em trii entre les coses o em tregui les dues.

pair<Pos, Dir>  busca(Pos p0, int id) { 	// posició i id del ciutadà que busca la millor casella
	  queue< pair<Pos, Dir> > q;
	  vector<vector<int>> dist(board_rows(), vector<int>(board_cols(), -1));
	  dist[p0.i][p0.j] = 0; //com es mira els indexs (i,j) de la posicio? 
	  Dir d = Down; //Inicialitzo amb una idrecció qualsevol
	  q.push({p0, d}); //?
	  
	  
	  while (not q.empty()) {
			auto x = q.front();
			Pos p = x.first;
			Dir d0 = x.second;
			q.pop();
			for (int k = 0; k < (int)dirs.size(); ++k) {
				Dir d = dirs[k];
				Pos np = p + d;
				if (pos_ok(np) and dist[np.i][np.j] == -1 and cell(np).type != Building) { //que no hi hagi un edifici en aquella direcció
					dist[np.i][np.j] = dist[p.i][p.j] + 1;
					if(dist[np.i][np.j] == 1) d0 = d;	//guardo la direcció cap a la que haurà d'anar el meu ciutadà
					
					//Busco amb restriccions:
					
					//Cas constructor (DIFERENCIAR: quanta vida tic/estic dins barricada/hi ha gent a prop): 
					if(citizen(id).type == Builder) { 
						
						//Busco vida: 
						if(citizen(id).life < builder_ini_life()/2) {
							if(cell(np).bonus == Food) {
								if(not is_day() and dist[np.i][np.j] < min(board_cols(), board_rows())/3) return  {np, d0};
								else {
									if(dist[np.i][np.j] < min(board_cols(), board_rows())/2) return  {np, d0};
								}
							}
						}
						
						//Busco diners: 
						if(cell(np).bonus == Money) {
							if(not is_day() and  dist[np.i][np.j] < min(board_cols(), board_rows())/5) return  {np, d0};
							else if(dist[np.i][np.j] < min(board_cols(), board_rows())/3) return  {np, d0};
						}

					}
				
				
					//Cas Guerrer:  
					else {	
						
						WeaponType arma = citizen(id).weapon;  //guardo el tipus d'arma del meu guerrer
						
						//Busco vida: 
						if(citizen(id).life < builder_ini_life()/2) {
							if(cell(np).bonus == Food) {
								if(not is_day() and dist[np.i][np.j] < min(board_cols(), board_rows())/5) return  {np, d0};
								else {
									if(dist[np.i][np.j] < min(board_cols(), board_rows())/3) return  {np, d0};
								}
							}
						}
						
						//Busco armes (si la puc millorar):						
						if(arma != Bazooka and cell(np).weapon != NoWeapon) { //si puc millorar l'arma
							if(cell(np).weapon == Bazooka and dist[np.i][np.j] < min(board_cols(), board_rows())/2) return  {np, d0};
							else if(cell(np).weapon == Gun and arma != Gun and dist[np.i][np.j] < min(board_cols(), board_rows())) return  {np, d0};
						}										
						
						//Busco diners: 
						if(cell(np).bonus == Money and dist[np.i][np.j] < min(board_cols(), board_rows())/5) {
							return {np, d0}; //POSO RESTRICCIÓ DE DISTANCIA?????
						}
						
						//Si puc (mirar si guanyo o perdo) ataco: VIDA!
						
						if((not is_day()) and cell(np).id != -1 and  citizen(cell(np).id).player != me()) {					
							if((citizen(cell(np).id).type == Builder or strongestWeapon(arma, citizen(cell(np).id).weapon) == arma)) return  {np, d0};
						}						
						
					}
					q.push({np, d0});	
				}
			}
	}
  return {p0, d}; 	//si torna la mateixa posició no em moc
}


//Diu si existeix alguna barricada (meva) al voltant de la posició p
bool barricades_voltant(Pos p) {
	for (int i = 0; i < (int)dirs.size(); ++i){
	      Dir d = dirs[i];
	      Pos np = p + d;
	      if (cell(np).b_owner == me()) return true;
	}
	return false;
}


  /**
   * Play method, invoked once per each round.
   */
  virtual void play () {
	  
	 //Guanyo punts: matant(100/250) o diners (evitar que em matin)
	 //Cerca en amplada per mirar que tinc més a prop i per cada jugador concret (de nit també apareixen coses);
	 
	  //WARRIORS + GUNS: vull que hem busquin la millor arma possible de dia i de nit busquin contricants (el més dolents possibles).
	  //de dia no pot atacar (s'ignorarà el moviment). Pot ocupar barricades del seu clan (des d'allà pot atacar i no el poden atacar)
	  //atacar constructor abans que guerrer abans?? que barricada (depen de si te constructor/guerrer/res a dintre)
	  //Pot guanyar diners i vida (VIDA_MAX = WARRIOR_INITIAL_LIFE). 
	  
	  
	  //BUILDERS: si es mou a una cela amb arma l'arma desapareix(evitar). BUILDER_INI_LIFE
	  
	  //FOOD: 20 vida. no poden tenir més de la vida inicial (no agafar menjar si tinc tota la vida)
	  
	  
	  //BARRICADES: les construeixen els builders NOMÉS DURANT EL DIA, des de dins només pots atacar, estàs defensat i no pots construir. 
	  //La cela ha d'estar buida. Els warriors també les poden utilitzar. Quan comença un dia s'eliminen. 
	  //Pots incrementar resistència fins punt màx_resist.Si ataques des de barricada és atac normal (no tens més defensa). NUM MAX DE BARRICAES!!!!!!!!!
	   
	  //MONEY: 5 punts
	  
	  
	  
	//CONSTRUCTORS I BARRICADES:
		
		//(Si el constructor té poca vida) si puc i és el final del dia (no nit) construeixo barricades:
		//M'asseguro de construir el màxim número de barricades permès per tenir els constructors protegits
		vector<Pos> bs = barricades(me());		
		vector<int> b = builders(me());
		
		
		
		
		//Al final del dia construeixo barricades, si puc les milloro i en cas de tenir-ne una al costat a la última ronda abans de la nit, hi entro:
		
		//Començo a construir barricades tenint en compte que les pugui millorar fins obtenir el màxim de resistència possible(puc millorar-les k vegades):
		int k = barricade_max_resistance()/barricade_resistance_step();
		
		if ((round()%(num_rounds_per_day()/2)) > ((num_rounds_per_day()/2) - k)) {	//Començo a construir per poder millorar-les k cops
			for (int i = 0; i < (int)b.size(); ++i) { // Iterate over all builders
				int id = b[i];
				Pos p = citizen(id).pos;
				
				//Entro a una barricada a la última ronda abans de la nit:
				if((round()%(num_rounds_per_day()/2)) == 24) {
					bool some_dir = false; 
					for (int i = 0; not some_dir and i < (int)dirs.size(); ++i){
						Dir d = dirs[i];
						Pos np = p + d;
						if (cell(np).b_owner == me()) { 
							move(id,d);    
							some_dir = true;
					  }
					}
				}
				
				
				//Si encara no és la última ronda abans de la nit millorar barricada :
				if((round()%(num_rounds_per_day()/2)) != 24 and barricades_voltant(p)) {		
					bool some_dir = false; 
					for (int i = 0; not some_dir and i < (int)dirs.size(); ++i){
						Dir d = dirs[i];
						Pos np = p + d;
						if (cell(np).b_owner == me()) { 
							build(id,d);    
							some_dir = true;
					  }
					}
				}
				
				
				//Construeixo una barricada:
				if ((int)bs.size() < max_num_barricades() and (not barricades_voltant(p)) and (citizen(id).life < 2*builder_ini_life()/3 or ((max_num_barricades() - (int)bs.size()) <= ((int)b.size() - i)))) { 
					bool some_dir = false;
					for (int j = 0; not some_dir and j < (int)dirs.size() and (int)bs.size() < max_num_barricades() ; ++j) {
						Dir d = dirs[j];
						Pos np = p + d;
						if (pos_ok(np) and cell(np).b_owner == -1 and cell(np).type == Street and cell(np).id == -1) { 
							build(id,d);   
							some_dir = true;
						}
					}				
				}
				
			}			
		}
		
		
		//DEFENSAT EN CAS DE TENIR ALGO AL COSTAT
		
		//Miro que tinc més proper i si puc vaig a la casella:
		for (int i = 0; i < (int)b.size(); ++i) { // Iterate over all builders		FER-HO AMB FOR id:b ???????????
			int id = b[i];
			Pos p = citizen(id).pos;
			
			Pos np = busca(p,id).first;
			Dir d = busca(p,id).second;
			
			if(np != p) move(id, d);
		}
	
		
		
	//GUERRERS (recolecta i atac): 
		vector<int> w = warriors(me());
		
		//cerca en amplada de caselles especials (no buides al seu entorn), vaig a la més propera amb ordre de prioritats:
		//DIA: vida (si necessari) i (no sé si posar les armes davant) diners (extra: cada 25 rondes es fa de nit/dia, al final del dia ja  busco armes) i sinó armes
		//NIT: vida(si necessari), armes/matar?? , diners		
		
		for (int id : w) { // Iterate over all warriors
			
			//Si tinc molt poca vida i barricades aprop, m'amago a una barricada (PENDENT A LA FUNCIÓ DFS):
			
			//Miro amb la funció busca què em surt més en compte a fer:
			Pos p = citizen(id).pos;
			
			Pos np = busca(p,id).first;
			Dir d = busca(p,id).second;
			
			if(np != p) move(id, d);				
		}	
		
}

};


/**
 * Do not modify the following line.
 */
RegisterPlayer(PLAYER_NAME);
