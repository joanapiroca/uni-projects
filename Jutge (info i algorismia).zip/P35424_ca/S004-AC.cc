#include "Player.hh"


/**
 * Write the name of your player and save this file
 * with the same name and .cc extension.
 */
#define PLAYER_NAME jou4


struct PLAYER_NAME : public Player {

  /**
   * Factory: returns a new instance of this class.
   * Do not modify this function.
   */
  static Player* factory () {
    return new PLAYER_NAME;
  }

  /**
   * Types and attributes for your player can be defined here.
   */

 const vector<Dir> dirs = {Up,Down,Left,Right};
 vector<int> bsb; //constructors sense barricada

//Diu si existeix alguna barricada (meva) al voltant de la posició p
bool barricades_voltant(Pos p) {
	for (int i = 0; i < (int)dirs.size(); ++i){
	      Dir d = dirs[i];
	      Pos np = p + d;
	      if (cell(np).b_owner == me()) return true;
	}
	return false;
}

//Diu si la posició p està amenazada per algún altre jugador:
bool amenaza(Pos p) {
	for (int k = 0; k < (int)dirs.size(); ++k) {
		Dir d = dirs[k];
		Pos np = p + d;
		if(cell(np).id != -1 and cell(np).id != me() and citizen(cell(np).id).type == Warrior) return true;
	}
	return false;
}

//Diu si és el constructor que no té barricada aquella nit:
bool no_barricada(int id) {
	 for (int k = 0; k < (int)bsb.size(); ++k) {
		 if(bsb[k] == id) return true;
	 }
	 return false;
 }

//FUNCIO PRINCIPAL DE CERCA EN AMPLADA:
pair<Pos, Dir>  busca(Pos p0, int id) { 	// posició id del ciutadà que busca la millor casella
	  queue< pair<Pos, Dir> > q;
	  vector<vector<int>> dist(board_rows(), vector<int>(board_cols(), -1));
	  dist[p0.i][p0.j] = 0; //com es mira els indexs (i,j) de la posicio? 
	  Dir d = Down; //Inicialitzo amb una idrecció qualsevol
	  q.push({p0, d}); //?
	  
	  
	  while (not q.empty()) {
			auto x = q.front();
			Pos p = x.first;
			Dir d0 = x.second;
			q.pop();
			for (int k = 0; k < (int)dirs.size(); ++k) {
				Dir d = dirs[k];
				Pos np = p + d;
				if (pos_ok(np) and dist[np.i][np.j] == -1 and cell(np).type != Building) { //que no hi hagi un edifici en aquella direcció
									
					dist[np.i][np.j] = dist[p.i][p.j] + 1;
					if(dist[np.i][np.j] == 1) d0 = d;	//guardo la direcció cap a la que haurà d'anar el meu ciutadà
					
					//Busco amb restriccions:
					
						//CONSTRUCTORS  
						if(citizen(id).type == Builder) { 
														
							//DE DIA
							if(is_day()) {
								//Si ho necessito, busco vida: 
								if(citizen(id).life < builder_ini_life()) {
									if(cell(np).bonus == Food) return {np, d0};
								}
								
								//Busco diners si tinc vida màxima:
								if(cell(np).bonus == Money) return  {np, d0};							
							}
							
							//DE NIT: no surten de la barricada, només cridarà aquesta funció en cas de ser el constructor que aquella nit no té barricada
							else {
								if(not amenaza(p0 + d0)) {
									//Si ho necessito, busco vida: 
									if(citizen(id).life < builder_ini_life()) {
										if(cell(np).bonus == Food) return {np, d0};
									}
									//Busco diners si tinc vida màxima:
									if(cell(np).bonus == Money) return  {np, d0};
								}
							}
						}
					
					
						//GUERRERS:  
						if(citizen(id).type == Warrior) {	
							
							WeaponType arma = citizen(id).weapon;  //guardo el tipus d'arma del meu guerrer
							
							//Busco vida: 
							if(citizen(id).life < builder_ini_life()) {
								if(cell(np).bonus == Food) return {np, d0};
							}
							
							
							//Busco armes (si la puc millorar):						
							if(arma != Bazooka and cell(np).weapon != NoWeapon) { 
								if(cell(np).weapon == Bazooka) return  {np, d0};
								else if(cell(np).weapon == Gun and arma != Gun) return {np, d0};
							}		
							
							//Busco diners: 
							if(is_day () and cell(np).bonus == Money) return {np, d0};
														
							//Si és de nit i si guanyo ataco : 							
							if((not is_day()) and cell(np).id != -1 and  citizen(cell(np).id).player != me() ) {					
								if(  citizen(cell(np).id).type == Builder or  
									(citizen(cell(np).id).type == Warrior and (arma == Bazooka and citizen(cell(np).id).weapon != Bazooka)) or
									(citizen(cell(np).id).type == Warrior and (arma == Gun and citizen(cell(np).id).weapon  == Hammer)) or
									//En aquest cas de tenir la mateixa arma, necessito tenir més vida:
									(citizen(cell(np).id).life < citizen(id).life)) {
									
									//Si no està en barricada:
									if(cell(np).resistance == -1) return {np, d0};
									//En cas d'haver barricada només vaig si tinc bazooka:
									else if(arma == Bazooka) return {np, d0};
								}
							}						
								
									
						}
						q.push({np, d0});
				}
			}
	}
  return {p0, d}; 	//si torna la mateixa posició no em moc
}


  /**
   * Play method, invoked once per each round.
   */
  virtual void play () {
	  
	 //Guanyo punts: matant(100/250) o diners (evitar que em matin)
	 //Cerca en amplada per mirar que tinc més a prop i per cada jugador concret (de nit també apareixen coses);
	 
	  //WARRIORS + GUNS: vull que hem busquin la millor arma possible de dia i de nit busquin contricants (el més dolents possibles).
	  //de dia no pot atacar (s'ignorarà el moviment). Pot ocupar barricades del seu clan (des d'allà pot atacar i no el poden atacar)
	  //atacar constructor abans que guerrer abans?? que barricada (depen de si te constructor/guerrer/res a dintre)
	  //Pot guanyar diners i vida (VIDA_MAX = WARRIOR_INITIAL_LIFE). 
	  
	  
	  //BUILDERS: si es mou a una cela amb arma l'arma desapareix(evitar). BUILDER_INI_LIFE
	  
	  //FOOD: 20 vida. no poden tenir més de la vida inicial (no agafar menjar si tinc tota la vida)
	  
	  
	  //BARRICADES: les construeixen els builders NOMÉS DURANT EL DIA, des de dins només pots atacar, estàs defensat i no pots construir. 
	  //La cela ha d'estar buida. Els warriors també les poden utilitzar. Quan comença un dia s'eliminen. 
	  //Pots incrementar resistència fins punt màx_resist.Si ataques des de barricada és atac normal (no tens més defensa). NUM MAX DE BARRICAES!!!!!!!!!
	   
	  //MONEY: 5 punts
	  
	  
	  
	//CONSTRUCTORS I BARRICADES:
		
		//(Si el constructor té poca vida) si puc i és el final del dia (no nit) construeixo barricades:
		//M'asseguro de construir el màxim número de barricades permès per tenir els constructors protegits
		vector<Pos> bs = barricades(me());		
		vector<int> b = builders(me());
		
		
		for (int i = 0; i < (int)b.size(); ++i) { // Iterate over all builders
			int id = b[i];
			Pos p = citizen(id).pos;
			
			
			
			//Guardo els constructors que no tenen barricada:
			if(round()%(num_rounds_per_day()/2) == 0) {
				if(i == 0) {
					vector<int> v;
					bsb = v;
				}
				if(cell(p).b_owner != me()) bsb.push_back(id);
			}
			
			//NIT : 
			if(not is_day()) {
				//Si m'estan ameneçant i no estic en una barricada fuig:
				if(amenaza(p)) {
					if(cell(p).b_owner == -1 or cell(p).resistance == 0) {
						
						//Busco direcció lliure:
						bool some_dir = false; 
						for (int i = 0; not some_dir and i < (int)dirs.size(); ++i){
							Dir d = dirs[i];
							Pos np = p + d;
							if (pos_ok(np) and cell(np).type != Building and cell(p).id == -1) { 
								move(id,d);    
								some_dir = true;
						  }
						}
					}
				}
				
				//Els que no tenen barricada aquella nit busquen coses:
				if(no_barricada(id)) {
					Pos np = busca(p,id).first;
					Dir d = busca(p,id).second;
					if(np != p) move(id, d);
				}
			}
		
			//DIA:
			else {
				//Al final del dia construeixo barricades, si puc les milloro i en cas de tenir-ne una al costat a la última ronda abans de la nit, hi entro:
				//Començo a construir barricades tenint en compte que les pugui millorar fins obtenir el màxim de resistència possible(puc millorar-les k vegades):
				int k = barricade_max_resistance()/barricade_resistance_step();
			
				if ((round()%(num_rounds_per_day()/2)) >= ((num_rounds_per_day()/2) - k)) {	//Començo a construir per poder millorar-les k cops
				
					
					//Entro a una barricada a la última ronda abans de la nit:
					if((round()%(num_rounds_per_day()/2)) == 24) {
						bool some_dir = false; 
						for (int i = 0; not some_dir and i < (int)dirs.size(); ++i){
							Dir d = dirs[i];
							Pos np = p + d;
							if (cell(np).b_owner == me()) { 
								move(id,d);    
								some_dir = true;
						  }
						}
					}
					
					
					//Si encara no és la última ronda abans de la nit millorar barricada :
					if((round()%(num_rounds_per_day()/2)) != 24 and barricades_voltant(p)) {		
						bool some_dir = false; 
						for (int i = 0; not some_dir and i < (int)dirs.size(); ++i){
							Dir d = dirs[i];
							Pos np = p + d;
							if (cell(np).b_owner == me()) { 
								build(id,d);    
								some_dir = true;
						  }
						}
					}
					
					
					//Construeixo una barricada:
					if ((int)bs.size() < max_num_barricades() and (not barricades_voltant(p)) and (citizen(id).life < 2*builder_ini_life()/3 or ((max_num_barricades() - (int)bs.size()) <= ((int)b.size() - i)))) { 
						bool some_dir = false;
						for (int j = 0; not some_dir and j < (int)dirs.size() and (int)bs.size() < max_num_barricades() ; ++j) {
							Dir d = dirs[j];
							Pos np = p + d;
							if (pos_ok(np) and cell(np).b_owner == -1 and cell(np).type == Street and cell(np).id == -1) { 
								build(id,d);   
								some_dir = true;
							}
						}				
					}
				}
				
				//Si encara és massa d'hora per construir barricades busco: 
				Pos np = busca(p,id).first;
				Dir d = busca(p,id).second;
				if(np != p) move(id, d);
			}			
		}
		
	
		
		
	//GUERRERS (recolecta i atac): 
		vector<int> w = warriors(me());
		
		//cerca en amplada de caselles especials (no buides al seu entorn), vaig a la més propera amb ordre de prioritats:
		//DIA: vida (si necessari) i (no sé si posar les armes davant) diners (extra: cada 25 rondes es fa de nit/dia, al final del dia ja  busco armes) i sinó armes
		//NIT: vida(si necessari), armes/matar?? , diners		
		
		for (int id : w) { // Iterate over all warriors
			
			//Si tinc molt poca vida i barricades aprop, m'amago a una barricada (PENDENT A LA FUNCIÓ DFS):
			
			//Miro amb la funció busca què em surt més en compte a fer:
			Pos p = citizen(id).pos;
			//guardo el tipus d'arma del meu guerrer
			WeaponType arma = citizen(id).weapon;  
			
			//Si m'estan ameneçant i no guanyo, fuig:
			if(amenaza(p) and (not is_day())) {
				Pos np = p;
				bool some_dir = false; 
					for (int i = 0; not some_dir and i < (int)dirs.size(); ++i){
						Dir d = dirs[i];
						np = p + d;
						if (pos_ok(np) and cell(np).type != Building and cell(p).id != -1) some_dir = true;
					}
					
				if(cell(np).id != -1 and  citizen(cell(np).id).player != me() ) {					
					if(not ((citizen(cell(np).id).type == Builder) or  
						(citizen(cell(np).id).type == Warrior and (arma == Bazooka and citizen(cell(np).id).weapon != Bazooka)) or
						(citizen(cell(np).id).type == Warrior and (arma == Gun and citizen(cell(np).id).weapon  == Hammer)) or
						//En aquest cas de tenir la mateixa arma, necessito tenir més vida:
						(citizen(cell(np).id).life < citizen(id).life)) ) {
						
						//Busco direcció lliure:
						bool some_dir = false; 
						for (int i = 0; not some_dir and i < (int)dirs.size(); ++i){
							Dir d = dirs[i];
							Pos np = p + d;
							if (pos_ok(np) and cell(np).type != Building and cell(p).id == -1) { 
								move(id,d);    
								some_dir = true;
						  }
						}
					}
				}
			}
			
			//Sinó busco:
			Pos np = busca(p,id).first;
			Dir d = busca(p,id).second;			
			if(np != p) move(id, d);				
		}	
		
}

};


/**
 * Do not modify the following line.
 */
RegisterPlayer(PLAYER_NAME);
