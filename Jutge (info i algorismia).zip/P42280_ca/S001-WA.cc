#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    
    int c = a*b;       // c són caselles 
    char m;           // m és monedes per casella
    int t = 0;       // t és monedes total
   
    
    while (c != 0) {
        cin >> m;
        t = t + m;
        c = c - 1;
    }
    
    cout << t << endl;
}
