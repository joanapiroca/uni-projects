#include <iostream>
using namespace std;

int main() {
    int n, m, a;
    cin >> n;
    m = n;
    int i;
    while ( n != 0){
        cin >> a;
        i = a;
        --n;
    }
    cout << "A la posicio " << m << " hi ha un " << i << '.' << endl;
}