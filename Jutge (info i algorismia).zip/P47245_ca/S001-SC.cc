#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
#include <queue>
#include <set>
#include <map>
using namespace std;

using ps = pair<string,string>;
using VE = vector<int>;
using VL = vector<long long>;
using VVE = vector<VE>;
using VS = vector<string>;
using VPS = vector<ps>;

int n;
VVE compt; //matriu d'entrada amb els ccomptadors a cada fila del N(0), S(1). O(2)i E(3)
VVE mapa; //mapa on hi ha els possibles edificis
VVE vistfila, vistcol; //Marco (i,j) quan l'ement j surt a la fila/columna 
                       //per no repetir elements en les permutacions


bool es_veu(int i, int j, string s) {
    //cout << "es_veu" << endl;
    
    int alcada = mapa[i][j];
    
    if(s == "nord") {
        for(int k = i; k >= 0; --k) {
            if(alcada < mapa[k][j]) return false;
        }
    }
   
    if(s == "oest") {
        for(int k = j; k >= 0; --k) {
            if(alcada < mapa[i][k]) return false;
        }
    }
    
    //cout << "true" << endl;
    return true;
}

void tapa(int i, int j, string s) {
    //cout << "tapa" << endl;
    int alcada = mapa[i][j];
    
    if(s == "sud"){
        for(int k = i; k >= 0; --k){
            if( alcada > mapa[k][j]) --compt[1][j];
        }
    }
    if(s == "est") {
        for(int k = j; k >= 0; --k){
            if( alcada > mapa[i][k]) --compt[3][i];
        }
    }
}


void escriu() {
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < n; ++j) cout << mapa[i][j];
        cout << endl;
    }
    for(int i = 0; i < 10; ++i) cout << '-';
    cout << endl;
}


//funció del backtracking: posició (i,j) de la matriu, edificis que de moment es veuen des de N,S,O,E
//N i O comencen a 0 i afegeixo edificis si no són tapas per ningú
//S i E comencen a 4 i elimino edificis quan són tapats pe algú
void f(int i, int j) {
    if(i == n) return escriu();
    if(j == n) f(i+1,0);
    
    for(int k = 0; k < n; ++k) {
        if(not vistfila[i][k] and not vistcol[j][k]) {
            mapa[i][j] = k;
            vistfila[i][k] = true;
            vistcol[j][k] = true;
            
            //Si és el primer o no el tapa ningú, el compto des del nord o oest
            if(i == 0 or es_veu(i, j, "nord")) {
                --compt[0][j];
                if(compt[0][j] < 0) return;
            }
            if(j == 0 or es_veu(i, j, "oest")) {
                --compt[2][i];
                if(compt[2][i] < 0) return;
            }
            
            //Sempre el veig des del sud o est però haig de descomptar a tots els edificis que ell tapa
            ++compt[1][j];
            if(i > 0) tapa(i,j,"sud");
            if(compt[1][j] < 0) return;
            
            ++compt[3][i];
            if(j > 0) tapa(i, j, "est");
            if(compt[3][i] < 0) return;
            
            f(i,j+1);
            
            //Pel backtracking:
            vistfila[i][k] = false;
            vistcol[j][k] = false;
        }
    }   
}

int main() {
    while(cin >> n) {
        compt = VVE(4, VE(n));
        for(int i = 0; i < 4; ++i) {
            for(int j = 0; j < n; ++j) cin >> compt[i][j];
        }
        
        mapa = VVE(n, VE(n, 0));
        vistfila = VVE(n, VE(n, false));
        vistcol = VVE(n, VE(n, false));
        
        //cout << "llegit" << endl;
        f(0,0);
    }       
        
}
