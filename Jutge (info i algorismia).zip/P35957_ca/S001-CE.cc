#include <iostream>
using namespace std;

int numero_central(int n) {
   
        int i = 0, m = n;
        while (n >= 10) {
            n = n / 10;
            ++i;
        }
        int a = i;
        
        while (i != (a/2)) {
        m = m%(10*i);
        --i;
        }
        return (m / (10*i);
    
}


int main() {
  int n;
  cin >> n;
  cout << numero_central(n) << endl;
}   