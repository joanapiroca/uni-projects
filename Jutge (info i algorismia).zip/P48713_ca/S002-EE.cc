#include <iostream>
using namespace std;

bool primer(int n){
    if(n < 2) return false;
    if (n > 1) {
        int i = n-1;
        while (i > 1 and (n%i != 0)) --i;
        if (i == 1) return true;
        else return false;
    }
}

int main() {
    int n, a;
    cin >> n;
    
    while (n != 0) {
        cin >> a;
        bool b = primer(a);
        if (b == true) cout << a << " es primer" << endl;
        if (b == false) cout << a << " no es primer" << endl;
        --n;
    }
}   
