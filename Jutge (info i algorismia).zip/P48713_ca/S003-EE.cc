#include <iostream>
#include <cmath>
using namespace std;


bool es_primer(int n){
    if (n < 2) return false;
    for (int i = 2; i*i <= n; ++i) {
        if (n%i == 0) return false;
    }
    return true;
}

int concatena(int n, int a) {
    int i = 1;
    if (a >= 10) {
        while ( (a/(10^i)) > 0) ++i;
        return (n*(10^i) + a);
    }
    else return (n*10 + a);
}

int main() {
    int n, a;
    cin >> n >> a;
    cout << concatena(n, a) << endl;
}


