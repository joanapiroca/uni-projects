#include <iostream>
#include <vector>
using namespace std;

bool hi_es(int x, const vector<int> & v) {
    for (int i = 0; i < (int)v.size(); ++i) {
        if (v[i] == x){
            return true;
            i = v.size();
        } 
    } 
    return false;
}
        

int main () {
  
}