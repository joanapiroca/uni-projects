#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

//SUMA ÚNICA

using VE = vector<int>;

int s, n;
VE v, surt;
bool trobat;

//i posició, sum el que em falta per sumar

//mira si és l'últim element a treure per no posar "+"
bool ultim(int i) {
    for(int j = i+1; j < n; ++j) {
        if(surt[j]) return false;
    }
    return true;
}

//el primer cop que entro trec el subconjunt
//i marco que ja l'he trobat perque no continui
void escriu() {
    if(not trobat) {
        cout << s << " = ";
        for(int i = 0; i < n; ++i) {
            if(surt[i]) cout << v[i] << (ultim(i) ? "" : " + ");
        }
        cout << endl;
    }
    trobat = true;
}


//backtracking
void f(int i, int sum){
    if (trobat) return;
    if(sum == 0) return escriu();
    if(i == n) return;
    
    surt[i] = 1; 
    f(i+1, sum - v[i]);
    surt[i] = 0;
    f(i+1, sum);    
}


int main() {
    while(cin >> s >> n) {
        trobat = false; //ho utilitzo per acabar un cop he trobat elsubconjunt
        v = VE(n);
        for(int i = 0; i < n; ++i) cin >> v[i];
        surt = VE(n, 0);    //guardo els que surten al subconjunt;
        
        f(0, s);
    }
}

