#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

//SUMA ÚNICA

using VE = vector<int>;

int s, n;
VE v, surt;
bool trobat;

//i posició, sum el que em falta per sumar

//mira si és l'últim element a treure per no posar "+"
bool ultim(int i) {
    for(int j = i+1; j < n; ++j) {
        if(surt[j]) return false;
    }
    return true;
}

//el primer cop que entro trec el subconjunt
//i marco que ja l'he trobat perque no continui
void escriu() {
    
    cout << s << " = ";
    for(int i = 0; i < n; ++i) {
       if(surt[i]) cout << v[i] << (ultim(i) ? "" : " + ");
    }
    cout << endl;
    trobat = true;
}


//backtracking
//guardo el sumatori dels elements que encara no he visitat del vector
void f(int i, int sum, int resta){
    if (trobat) return;
    if(sum == 0 or resta == sum) {
        if(resta == sum) {
            for(int j = i; j < n; ++j) surt[j]=1;
        }
        return escriu();
    }
        
    if(i == n or resta < sum ) return;
    
    surt[i] = 1; 
    f(i+1, sum - v[i], resta-v[i]);
    surt[i] = 0;
    f(i+1, sum, resta-v[i]);    
}


int main() {
    while(cin >> s >> n) {
        trobat = false; //ho utilitzo per acabar un cop he trobat elsubconjunt
        v = VE(n);
        for(int i = 0; i < n; ++i) cin >> v[i];
        surt = VE(n, 0);    //guardo els que surten al subconjunt;
        
        int res = 0;
        for(int i = 0; i < n; ++i) res = res + v[i];
        if(s > 0) f(0, s, res);
    }
}

