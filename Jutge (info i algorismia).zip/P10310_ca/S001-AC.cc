#include<vector>
#include <iostream>
using namespace std;

void seguent_fibonacci(int& f0, int& f1, int& f2) {
     int aux = 0;
     aux = f2;
     f2 = f1 + f2;
     f0 = f1;
     f1 = aux;
}

void anterior_fibonacci(int& f0, int& f1, int& f2) {
    int aux = f1;
    f2 = f1;
    f1 = f0;
    f0 = aux - f0;
}

void linia(vector<int> v) {
    for(int i = 0; i < (v.size()-1); ++i) cout << v[i] << " ";
    cout << v[v.size() - 1] << endl;
}

bool zeros(vector<int> v) {
    for(int i = 0; i < v.size(); ++i) if (v[i] != 0)return true;
    return false;
}

int main() {
    int n;
    while(cin >> n) {
        vector<int> v(n);
        for(int i = 0; i < n; ++i) cin >> v[i];
        int f0 = 0, f1 = 1, f2 = 1, aux = 0;
       
        while( zeros(v) == true ) {  // tots diferents a 0
            for(int i = 0; i < n; ++i) {
                while (v[i] >= f2) {
                    v[i] = v[i] - f2;
                    linia(v);
                    seguent_fibonacci(f0, f1, f2);
                }
            }
            anterior_fibonacci(f0, f1, f2);
        }
        cout << endl;
    }
}
    
