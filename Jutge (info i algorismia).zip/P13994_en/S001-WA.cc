#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

using VE = vector<int>;
using ME = vector<VE>;
using VS = vector<string>;
using p = pair<int,int>;
using VP = vector<p>;
using MP = vector<VP>;

int x, y;
VE dist, pare;
MP G;
int n, m;

void dijkstra() {
	dist = VE(n, 1e9);
	pare = VE(n, -1);
	priority_queue<p> q;
	dist[x] = 0;
	pare[x] = -2;
	q.push({0,x});
	
	while(not q.empty()) {
		p a = q.top();
		q.pop();
		int d = -a.first;
		int u = a.second;
		if(d == dist[u]) {
			if(u == y) return;
			
			for(int i = 0; i < (int)G[u].size(); ++i) {
				int c = G[u][i].first;
				int v = G[u][i].second;
				int d2 = d+c;
				if(d2 < dist[v]) {
					dist[v] = d2;
					pare[v] = u;
					q.push({-d2, v});
				}
			}
		}
	}
}
		
		
	
int main() {
	while(cin >> n >> m) {
		int u, v, c;
		G = MP(n);
		while(m--) {
			cin >> u >> v >> c;
			G[u].push_back({c,v});
		}
		cin >> x >> y;
		
		dijkstra();
		if(pare[y] == -1) cout << "no path from " << x << " to " << y;
		else{
			//primer giro el camí amb una pila
			stack<int> s;
			while(y != x) {
				s.push(y);
				y = pare[y];
			}
			cout << x << " ";
			while(not s.empty()) {
				cout << s.top() << " ";
				s.pop();
			}
			cout << endl;	
		}
	}
}
		
			
			
