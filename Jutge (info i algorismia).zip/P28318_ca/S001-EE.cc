#include <iostream>
#include <vector>
using namespace std;

int main () {
    int n, m; //n files, m columnes
    cin >> n >> m;
    int a[n][m];    
    //LLegeix matriu
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) cin >> a[i][j];
    }
    
    int c,d;
    string b;
    
    while (cin >> b) {
        if (b == "fila") {
            cin >> c;
            cout << "fila "<< c << ": ";
            for (int j = 0; j < m; ++j) cout << a[c-1][j] << " ";
            cout << endl;
        }
            
        if (b == "columna") {
            cin >> c;
            cout << "columna "<< c << ": ";
            for (int i = 0; i < m; ++i) cout << a[i][c-1] << " " ;
            cout << endl;
        }
        if (b == "element") {
            
            cin >> c >> d;
            cout << b << " " << c << " " << d << ": " << a[c-1][d-1] << endl;
        }  
    }
}
