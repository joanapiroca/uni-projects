#include <iostream>
#include <vector>
using namespace std;

using VE = vector<int>;
using VS = vector<string>;


int n;
VE v;
VS par;

void escriu() {
    cout << "{" ;
    for(int i = 0; i < n; ++i) {
        if(v[i]) cout << par[i] << (i != n-1 ?  "," : ""); //com veure que és l'últim element del subconjunt (= últim 1)
    }
    cout << "}" << endl;
}

void f(int i) {
    if(i == n) return escriu();
    v[i] = 0;
    f(i+1);
    v[i] = 1;
    f(i+1);
}

int main() {
    cin >> n;
    v = VE(n);
    par = VS(n);
    for (string& s : par) cin >> s; 
    f(0);
}

