#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;
using VS = vector<string>;

int n;
VE perm;
VS par;


void escriu() {
    cout << "(";
    for(int i = 0; i < n; ++i) cout << par[perm[i]] << (i == n-1 ? "" : ",");
    cout << ")" << endl;
}


void f(int i) {
	if(i == n)return escriu();
	for(int j = 0; j < n; ++j) {
		perm[i] = j; //el poso a la posició i
		f(i+1); //omplo la següent posició
	}
}


int main() {
    cin >> n;
    perm = VE(n); //guarda la permutació
    par = VS(n);
    for(int i = 0; i < n; ++i) cin >> par[i];
    f(0);
}


