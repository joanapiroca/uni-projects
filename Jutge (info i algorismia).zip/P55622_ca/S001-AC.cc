#include <iostream>
using namespace std;

int main () {
    int a;
    cin >> a;
    
    int i;
    int b;
    i = 0;
    b=a;
    if (b >= 1) {
        while ( b >= 1) {
            b = b/10;
            i = i+1;
        }
     cout << "El nombre de digits de " << a << " es " << i << "." << endl;
    }
   else cout << "El nombre de digits de 0 es 1." << endl;  
}
