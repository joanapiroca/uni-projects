#include <iostream>
#include <vector>
using namespace std;

vector<int> concatenacio(const vector<int> v1, const vector<int> v2) {
    for (int i=0; i < v2.size(); ++i) {
        v1.push_back(v2[i]);
    }
}

int main () {
   
}
