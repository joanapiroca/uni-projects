#include <iostream>
#include <vector>
using namespace std;

vector<int> concatenacio(const vector<int>& v1, const vector<int>& v2) {
    int n = v1.size(), m = v2.size();
    vector<int> v(n+m);
    for (int i = 0; i < n; ++i) v[i] = v1[i];
    for (int i= n; i < n+m; ++i) v[i] = v2[i-n];
    return v;
}

int main () {
   
}
