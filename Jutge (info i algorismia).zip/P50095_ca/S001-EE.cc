#include <iostream>
using namespace std;

bool primer(int n){
    if(n == 1 or n == 2) return false;
    if (n > 1) {
        int i = n-1;
        while (i > 1 and (n%i != 0)) --i;
        if (i == 1) return true;
        else return false;
    }
}

int main() {
    int n;
    while (cin >> n){
        int i = n + 1;
        while(primer(i) == false) ++i;
        cout << i << endl;
    }
}   
