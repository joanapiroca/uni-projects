#include <iostream>
using namespace std;

bool primer(int n) {
	if (n<2) return true;
	for (int i=2; i*i<=n; ++i) {
		if (n%i==0) return false;
	}
	return true;
}


int main() {
    int n;
    while (cin >> n and primer(n)) {
            int i = n + 1;
            while(primer(i) == false) ++i;
            cout << i << endl;
    }
}   
