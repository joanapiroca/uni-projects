#include <iostream>
#include <vector>
using namespace std;

int main () {
    int n, m, cont = 0;
    cin >> n;
    
    vector<int> a;
    for (int i=0; i < n and cin >> m; ++i) a.push_back(m);
    for (int i=0; i < n-1; ++i) if (a[i] == a[n-1]) ++cont;
    
    cout << cont << endl;       
}
