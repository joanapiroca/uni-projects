#include <iostream>
#include <vector>
#include <algorithm>
#include <string> 
#include <cmath>
using namespace std;

void treure_matriu(vector<vector<char>> M,const int n,const int m) {
    for(int i = 0; i < n; ++i){
        for(int j = 0; j < m; ++j) cout << M[i][j];
        cout << endl;
    }
}


bool guanyat(vector<vector<char>> M, char a,const int i,const int j,const int n,const int m) {
    string oso = "OSO";
    string b; //compararem a amb oso;
    
    
    if(n < 3) {     // nomes hem d'estudiar casos horitzontals
        if(m < 3) return false;
        if(m == 3) {
            for(int k = 0; k < 3; ++k) b.push_back(M[i][k]);
            if(oso == b) return true;
        }
        if(j == 0) {
            for(int k = 0; k < 3; ++k) b.push_back(M[i][k]);
            if(oso == b) return true;
        }
        
        if(j == m-1) {
            for(int k = m-1; k > 0; --k) b.push_back(M[i][k]);
            if(oso == b) return true;
        }        
    }
    
    
    if(m < 3) {     // nomes casos verticals
        if(n < 3) return false;
        if(n == 3) {
            for(int k = 0; k < 3; ++k) b.push_back(M[k][j]);
            if(oso == b) return true;
        }
        if(i == 0) {
            for(int k = 0; k < 3; ++k) b.push_back(M[k][j]);
            if(oso == b) return true;
        }
        
        if(i == m-1) {
            for(int k = n-1; k > 0; --k) b.push_back(M[k][j]);
            if(oso == b) return true;
        }  
    }
}

int main() {
   int n, m;
   
   while(cin >> n >> m) {
       vector<vector<char>> M;
       int cont = 0; //conta els torns, els parells juga l'anna els imparells el Bernat
       int i, j;
       char a;
       bool acabar = false;
       
       while(cont <= n*m and acabar == false) {
           cin >> i >> j >> a;
           M[i][j] = a;
           
           if(cont >= 3) {
               if( guanyat(M, a, i, j, n, m) == true) {
                   acabar = true;
                   if (cont%2 == 0) {
                       cout << "Anna" << endl;
                       treure_matriu(M, n, m);
                    }
                    else {
                        cout << "Bernat" << endl;
                        treure_matriu(M, n, m);
                    }
                }
            }
            ++cont;
        }
        if (acabar == false) {
            cout << "empat" << endl;
            treure_matriu(M, n, m);
        }
    }   
}
