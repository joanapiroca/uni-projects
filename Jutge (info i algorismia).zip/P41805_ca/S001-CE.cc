#include <iostream>
#include <vector>
#include <algorithm>
#include <string> 
#include <cmath>
using namespace std;

void treure_matriu(vector<vector<char>> M) {

}


bool guanyat(vector<vector<char>> M, char a,const int i,const int j,const int n,const int m) {
    string oso = "OSO";
    string a; //compararem a amb oso;
    
    
    if(n < 3) {     // nomes hem d'estudiar casos horitzontals
        if(m < 3) return false;
        if(j == 0)
    }
    
    if(m < 3) {     // nomes casos verticals
        
    }
}

int main() {
   int n, m;
   
   while(cin >> n >> m) {
       vector<vector<char>> M;
       int cont = 0; //conta els torns, els parells juga l'anna els imparells el Bernat
       int i, j;
       char a;
       bool acabar = false;
       
       while(cont <= n*m and acabar == false) {
           cin >> i >> j >> a;
           M[i][j] = a;
           
           if(cont >= 3) {
               if( guanyat(M, a, i, j, n, m) == true) {
                   acabar = true;
                   if (cont%2 == 0) {
                       cout << "Anna" << endl;
                       treure_matriu(M);
                    }
                    else {
                        cout << "Bernat" << endl;
                        treure_matriu(M);
                    }
                }
            }
            ++cont;
        }
        if (acabar == false) {
            cout << "empat" << endl;
            treure_matriu(M);
        }
    }   
}
