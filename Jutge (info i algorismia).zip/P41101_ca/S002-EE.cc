#include <iostream>
#include <vector>
using namespace std;

bool tots(const vector<bool> p) {
    for(int i = 0; i < p.size(); ++i){
        if(p[i] == false) return false;
    }
    return true;
}

int main() {
    int n;
    while(cin >> n) {
        if(n == 1){
            int b; 
            cin >> b;
            cout << 1 << endl;
        } 
        else {
            vector<int> v(n);
            for(int i = 0; i < n; ++i) cin >> v[i];
            vector<bool> p(n, false);
        
    
            int max = 1;
            int i = 0;
            while(false == tots(p) and i < n) {
                if(p[i] == true) ++i;
                else{
                    p[i] = true;
                    int k = v[i] -1;
                    int cont = 1;
                    while(k != i) {
                        ++cont;
                        p[k] = true;
                        k = v[k] -1;
                    }
                    if(cont > max) max = cont;
                    ++i;
                }
            }
            
            cout << max << endl;
        }
    }
   
}
