#include <vector>
#include <iostream>

using namespace std;

vector<int> ex_union(const vector<int>& v1, const vector<int>& v2) {
    int i = 0;
    int j = 0;
    vector<int> v(1,0);
    while(i < v1.size() and j < v2.size()) {
        if(v1[i] == v1[i-1]) ++i;
        if(v2[j] == v2[j-1]) ++j;
        if(v1[i] < v2[j]) {
            if(v[v.size()-1] != v1[i]) {
                v.push_back(v1[i]);
                ++i;
            }
            else ++i;
        }
        
        else if(v1[i] == v2[j]) {
            ++i;
            ++j;
        }
        
        else {
            if(v[v.size()-1] != v2[j]) {
                v.push_back(v2[j]);
                ++j;
            }
            else ++j;
        } 
    }
    
    while(i < v1.size()) {
        if(v1[i] == v1[i-1]) ++i;
        else if(v[v.size()-1] != v1[i]) {
            v.push_back(v1[i]);
            ++i;
        }
        else ++i;
    }
    
    while(j < v2.size()) {
        if(v2[j] == v2[j-1]) ++j;
        else if(v[v.size()-1] != v2[j]) {
            v.push_back(v2[j]);
            ++j;
        }
        else ++j;
    }
    v.erase(v.begin() + 0);
    return v;
}


int main() {
    vector<int> v1(4);
    vector<int> v2(4);
    
    for(int i = 0; i < 4; ++i) cin >> v1[i];
    for(int i = 0; i < 4; ++i) cin >> v2[i];
    
    for(int i = 0; i < 2; ++i) cout << ex_union(v1, v2)[i] << endl;
}
