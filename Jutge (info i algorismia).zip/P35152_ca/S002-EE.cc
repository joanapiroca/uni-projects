#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

bool altre(int x, const vector<int>& v) {
    for(int i = 0; i < v.size(); ++i){
        if(v[i] == x) return false;
    }
    return true;
}


vector<int> ex_union(const vector<int>& v1, const vector<int>& v2) {
    vector<int> v;
    for(int i = 0; i < v1.size(); ++i) {
        if(altre(v1[i], v2)) {
            if(v.size() != 0) {
                if(altre(v1[i], v) ) v.push_back(v1[i]);
            }
            else v.push_back(v1[i]);
        }
    }
    
    for(int i = 0; i < v2.size(); ++i) {
        if(altre(v2[i], v1) ) {
            if(v.size() != 0) {
                if(altre(v2[i], v) ) v.push_back(v2[i]);
            }
            else v.push_back(v2[i]);
        }
    }
    
    sort(v.begin(),v.end() );
    return v;
}


int main() {
    vector<int> v1(4);
    vector<int> v2(4);
    
    for(int i = 0; i < 4; ++i) cin >> v1[i];
    for(int i = 0; i < 4; ++i) cin >> v2[i];
    
    for(int i = 0; i < 2; ++i) cout << ex_union(v1, v2)[i] << endl;
}
