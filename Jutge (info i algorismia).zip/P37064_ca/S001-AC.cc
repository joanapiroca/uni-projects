#include <iostream>
#include <vector>
#include <set>
using namespace std;

int main() {
	string a;
	set<string> s;
	int n = 1;
	set<string>::iterator med;
	while(cin >> a and a != "END") {
		s.insert(a);
		if(n == 1) med = s.begin();
		else if(n%2 == 0){
			if( *(med) >= a ) --med;
		}
		else if( *med < a) ++med;	
		cout << *med << endl;
		++n;
	}
}
