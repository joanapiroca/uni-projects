#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;
using VS = vector<string>;

int n;
VE v, perm;
VS par;


void escriu() {
    cout << "(";
    for(int i = 0; i < n; ++i) cout << par[perm[i]] << (i == n-1 ? "" : ",");
    cout << ")" << endl;
}


void f(int i) {
	if(i == n)return escriu();
	for(int j = 0; j < n; ++j) {
		if(not v[j]) { //si el nombre j encara no ha sortit
			perm[i] = j; //el poso a la posició i
			v[j] = 1;
			f(i+1); //omplo la següent posició
			v[j] = 0;
		}
	}
}


int main() {
    cin >> n;
    v = VE(n,0); //marca els nombres que ja apareixen a la permutacio
    perm = VE(n); //guarda la permutació
    par = VS(n);
    for(int i = 0; i < n; ++i) cin >> par[i];
    f(0);
}


