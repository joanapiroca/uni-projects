#include <iostream>
#include <cmath>
using namespace std;

int factorial(int n) {
    if (n <= 1) return 1;
    return factorial(n-1)*n;
}

void linia1(int c) {
    cout << c << "|";
    for (int i = 1; i <= c; ++i) cout << "X";
    cout << endl;
}
    
void linia2(int c) {
    if (c < 10) {
        cout << " " << c << "|";
        for (int i = 1; i <= c; ++i) cout << "X";
        cout << endl;
    }
        
    if (c > 35) {
        cout << c << "|";
        for (int i = 1; i <= 35; ++i) cout << "X";
        cout << endl;
    }
    
    else {
        cout << c << "|";
        for (int i = 1; i <= c; ++i) cout << "X";
        cout << endl;
    }
}

void linia3(int c) {
    if (c < 10) {
        cout << "  " << c << "|";
        for (int i = 1; i <= c; ++i) cout << "X";
        cout << endl;
    }
    if (c > 10 and c <= 35) {
        cout << " " << c << "|";
        for (int i = 1; i <= c; ++i) cout << "X";
        cout << endl;
    }
    
    if (c > 35  and c < 100) {
        cout << " " << c << "|";
        for (int i = 1; i <= 35; ++i) cout << "X";
        cout << endl;
    }
    
    else {
        cout << c << "|";
        for (int i = 1; i <= 35; ++i) cout << "X";
        cout << endl;
    }
}
         

int main () {
    int n, c;
    cin >> n;    
        
    if ((factorial(n) / (factorial(n/2 + 1)* factorial(n - (n/2 + 1)))) >= 100) {
        for (int k = 0; k <= n; ++k) {
           c = (factorial(n) / (factorial(k)* factorial(n - k)));
           linia3(c);
        }
    }
    
    if ((factorial(n) / (factorial(n/2 + 1)* factorial(n - (n/2 + 1)))) >= 10 ) {
        for (int k = 0; k <= n; ++k) {
            c = (factorial(n) / (factorial(k)* factorial(n - k)));
            linia2(c);
        }
    }
    
    if ((factorial(n) / (factorial(n/2 + 1)* factorial(n - (n/2 + 1)))) < 10) {
        for (int k = 0; k <= n; ++k) {
            c = (factorial(n) / (factorial(k)* factorial(n - k)));
            linia1(c);       
        }
    }
}
    
