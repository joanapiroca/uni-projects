#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

//DÍGITS EN ORDE ÒPTIM

using VE = vector<int>;
using VEE = vector<VE>;

VEE M;
VE v, surt, p;   
int m, n;

//guardo els possibles premis a p i després calculo el màxim
// v vector que guarda el resultat
//surt marca els ombres de n que han sortit

//i és la posició de v
//valor dels i primers nombres per mirar si son multiples de m;
//acumulo el premi

void f(int i, int valor, int premi) { 
      
    if(i == n) {
        p.push_back(premi);
        return;
    }
    
    for(int j = 0; j < n; ++j) {        
        if(surt[j] == 0) {
            valor = 10*valor+j;
            if(valor%m != 0) {
                v[i] = j;
                surt[j] = 1;
                
                if(i != 0) f(i+1, valor, premi + M[v[i-1]][j]);
                else f(i+1, valor, premi);
                surt[j] = 0;
            }
        }        
    }   
}

int maxim(VE v) {
    int res = 0;
    int s = v.size();
    for(int i = 0; i < s; ++i) {
        if( v[i] > res) res = v[i];
    }
    return res;
}

int main() {
    while(cin >> m >> n) {
        M = VEE(n, VE(n, 0));
        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < n; ++j) cin >> M[i][j];
        }
        
        v = VE(n);
        surt = VE(n, 0);
        f(0,0,0);
        
        if(p.empty()) cout << 0 << endl;
        else cout << maxim(p) << endl;
    }
}
