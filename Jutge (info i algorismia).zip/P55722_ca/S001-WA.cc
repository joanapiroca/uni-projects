#include <iostream>
#include <cmath>
using namespace std;

int nombre_digits(int n) {
    int i = 0;
    
    while (n >= 1) {
         n = n/10;
         i = i + 1;  
    }
    return i;
}


int main() {
    int n;
    cin >> n;
    cout << nombre_digits(n) << endl;
}
