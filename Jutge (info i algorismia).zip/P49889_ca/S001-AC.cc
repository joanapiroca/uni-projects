#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;
using VS = vector<char>;

int n;
VE v, perm;
VS lletres;

void escriu() {
	for(int i = 0; i < 2*n; ++i) cout << lletres[perm[i]];
	cout << endl;
}

void f(int i) {
	if(i == 2*n) return escriu();
	
	if(i%2 == 0) { //on ha d'haver consonants
		for(int j = 0; j < n; ++j) {
			if(not v[j]) {
				perm[i] = j;
				v[j] = 1;
				f(i+1);
				v[j] = 0; // pel backtracking
			}
		}
	}
	
	else {
		for(int j = n; j < 2*n; ++j) {
			if(not v[j]) {
				perm[i] = j;
				v[j] = 1;
				f(i+1);
				v[j] = 0; //pel backtracking
			}
		}
	}
}
	
		


int main() {
	cin >> n;
	lletres = VS(2*n);	
	for(int i =  0; i < 2*n; ++i) cin >> lletres[i]; //les primeres n son consonants i les ultimes n son vocals
	
	perm = VE(2*n); //guarda l'ordre de les lletres (enters)
	v = VE(2*n, 0); //marca quines llet. han sortit (boolears)
	f(0);

}
