#include <iostream>
#include <vector>
using namespace std;

int posicio_maxim(const vector<double>& v, int m){
    
    double max = v[0];
    int pos;
    
    for(int i = 0; i < m; ++i) {
        if(v[i] > max) { 
            max = v[i];
            pos = i+1;
        }        
    }
    return pos;    
}

int main () {
    
}
        
            
            
            
            
            
            
            
    
