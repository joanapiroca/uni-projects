#include <iostream>
#include <vector>
using namespace std;

int posicio_maxim(const vector<double>& v, int m){
    int i = 0;
    double max = v[0];
    int pos;
    
    while ( i <= m) {
        if(v[i] > max) { 
            max = v[i];
            pos = i;
        }        
    }
    return pos;    
}

int main () {
    
}
        
            
            
            
            
            
            
            
    
