#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

using p = pair<int,int>;
using VP = vector<p>;
using VE = vector<int>;

int t, n;
VE k, temps;

int f(int i, int know,int tused) {
	if(tused > t) return 0;
	if(tused == t) return know;
	if(i == n) return know + (t - tused);
	return max( f(i+1, know,tused), f(i+1, know + k[i], tused + temps[i]));
}


int main() {
	while(cin >> t >> n) {
		temps = k = VE(n);
		for(int i = 0; i < n; ++i) cin >> temps[i] >> k[i];
		
		
		cout << f(0,0,0) << endl;
		
	}
}
	
