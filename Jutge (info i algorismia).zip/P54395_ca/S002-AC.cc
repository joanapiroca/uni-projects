#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

using p = pair<int,int>;
using VP = vector<p>;
using VE = vector<int>;
using VVE = vector<VE>;

int t, n; 
VE k, temps;
VVE m;

//maxim knowledge que pot adquirir si tenim temps "j" i només utilitzem els "i" primers vídeos; 
int f(int i, int j) {
	//if(j < 0) return j+temps[i+1];
	
	int& res = m[i][j];
	if(j == 0) return res = 0;
	if(i == 0) return res = j;

	if(res != -1) return res;
	
	if(j - temps[i-1] < 0) return res = max(f(i-1, j), j);
	return res = max( f(i-1, j), f(i-1, j - temps[i-1]) + k[i-1]);
}


int main() {
	while(cin >> t >> n) {
		temps = k = VE(n);
		for(int i = 0; i < n; ++i) cin >> temps[i] >> k[i];
		
		m = VVE(n+1, VE(t+1, -1));
		
		cout << f(n,t) << endl;
		
	}
}
	
