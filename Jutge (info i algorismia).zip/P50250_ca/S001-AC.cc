#include<iostream>
#include<vector>
using namespace std;

int main() {
    int n, m , t;
    while(cin >> n >> m >> t) {
        vector<bool> fil(n, true);
        vector<bool> col(m, true);
        
        int x, y;
        for(int i = 0; i < t; ++i) {
            cin >> x >> y;
            fil[x-1] = false;
            col[y-1] = false;
        }
 
        
        int fil_buides = 0;
        int col_buides= 0;
        for(int i = 0; i < n; ++i) {
            if(fil[i]) ++fil_buides;
        }
        
        for(int j = 0; j < m; ++j) {
            if(col[j]) ++col_buides;
        }
        
        cout << fil_buides*col_buides << endl;
        
    }
}
