#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

int main() {
	int n;
	cin >> n;
	cout << 2 << endl;
}
