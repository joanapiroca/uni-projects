#include <iostream>
#include <vector>
using namespace std;

typedef vector< vector<int> > Matriu;
Matriu suma(const Matriu& a, const Matriu& b){
    int row = a.size();
    int col = a.size();
    Matriu c(row, vector<int> (col));
    
    for (int i=0; i < row; ++i) {
        for (int j=0; j < col; ++j)  c[i][j] = a[i][j] + b[i][j];
    }
    
    return c;
}

int main () {
 
}
