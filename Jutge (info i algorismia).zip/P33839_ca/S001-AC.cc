#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int a;
    
    
     while ( cin >> a) {
     int p = 0;
     int b = a;    
         while (a > 0) {
             p = p + a%10;
             a = a/10;
         }
     cout << "La suma dels digits de " << b << " es " << p << "." << endl;
     }    
}
