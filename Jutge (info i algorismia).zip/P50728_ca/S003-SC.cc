#include <iostream>
#include <vector>
#include <algorithm>
#include <string> 
#include <cmath>
using namespace std;


int posicio_minim(vector<string> v, int i) {
    int n = v.size() - 1;
    int pos_min = i;
    for(int j = i; j < n; ++j) {
        if(v[i].size() < v[pos_min].size()) pos_min = i;
    }
    return pos_min;
}



//ho ordeno per separat i els fusiono;

vector<string> ordena_sense_sort(const vector<string>& V) {
    vector<string> min; //vector amb les paraules minuscules
    vector<string> maj;//vector amb les paraules majúscules
    
    for(int i = 0; i < (int)V.size(); ++i) { //separo els vectors
       
        if( 'V[i][0]' > 'a') min.push_back(V[i]);  //primera lletra de cada string
        else maj.push_back(V[i]);
    }
    
    for(int ult = 0; ult < (int)min.size()-1; ++ult) { //ordeno per selecció perquè no em funciona el merge sort;
        int x = posicio_minim(min, ult);
        swap(min[x], min[ult]);
    }
    
    for(int ult = 0; ult < (int)maj.size()-1; ++ult) {  
        int x = posicio_minim(maj, ult);
        if(x != ult) swap(maj[x], maj[ult]);
    }
    
    vector<string> res; //els junto en un vector, primer les minúscules i després les majúscules
    
    for(int i = 0; i < (int)min.size(); ++i) res.push_back(min[i]);
    for(int j = 0; j < (int)maj.size(); ++j) res.push_back(maj[j]);
    
    return res;
}

int main() {
  
}


