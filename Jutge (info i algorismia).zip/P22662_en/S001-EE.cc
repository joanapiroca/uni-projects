#include <iostream>
#include <vector>
#include <queue>
#include <stack>
using namespace std;

using VE = vector<int>;
using VVE = vector<VE>;


int n;
VE v, vist;
VVE g; //arestes entre els vèrtexs (ÍNDEXS NO VALORS)


int gcd(int x, int y) {
	if(y == 0) return x;
	return gcd(y, x%y);
}


int dfs(int i) {
	stack<int> s;
	s.push(i);
	vist[i] = true;
	int m = 0;
	
	while(not s.empty()) {
		++m;
		int x = s.top();
		s.pop();
		vist[x] = true;
		
		for(auto y : g[x]) {
			
			if(not vist[y]) s.push(y);
		}
	}
	return m;
}

int main() {
	while(cin >> n) {
		v = VE(n);
		g = VVE(n);
		for(int i = 0; i < n; ++i) cin >> v[i];
		
		for(int i = 0; i < n; ++i) {
			for(int j = 0; j < i; ++j) {
				if(gcd(v[i], v[j]) > 1) {
					g[i].push_back(j);
					for(auto& x : g[j]) {
						g[i].push_back(x);
						g[x].push_back(i);
					}
					g[j].push_back(i);
				}
			}
		}
		
		vist = VE(n, false);
		int max = 0;
		
		for(int i = 0; i < n; ++i) {
			if(not vist[i]){
				 int mida = dfs(i);
				 if(mida > max) max = mida;
			 }
		 }
		 
		 cout << max << endl;
	}
}
		
			
