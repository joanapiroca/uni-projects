#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool restriccio(const int& d, const int& x, const int& y) {
    if(x >= y and (x-y) >= d) return true;
    if(x < y and (y-x) >= d) return true;
    return false;
}

int main() {
    int n, d;
    while(cin >> n >> d) {
        vector<int> v(n, 0);
        for(int i = 0; i < n; ++i) cin >> v[i];
        sort(v.begin(), v.end());
        
        
        for(int i = n-1; i > 0; --i) {
            int j = i-1;
            while(j >= 0 ) {
                if(not restriccio(d, v[j], v[i])) {
                    v.erase(v.begin() + j);
                    --i;
                }
                --j;
            }
        }
        
        int sum = 0;
        for(int i = 0; i < (int)v.size(); ++i) sum = sum + v[i];
        
        cout << sum << endl;  
    }
}
