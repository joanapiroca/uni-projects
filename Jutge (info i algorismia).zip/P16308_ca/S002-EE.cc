#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
#include <queue>
#include <set>
#include <map>
using namespace std;

using ps = pair<string,string>;
using VE = vector<int>;
using VL = vector<long long>;
using VVE = vector<VE>;
using VS = vector<string>;
using VPS = vector<ps>;

//faig un set per poder buscar els veins amb cost log(n)
//guardo les mutacions ordenades en un vector per poder seguir l'ordre quan llegeixi els ti

VE t;
int n;



int main() {
    while(cin >> n) {
        map<string, string> s;
        string a, fletxa, b;
        
        //Guardo el graf en un set (els strings origen i destí de les n arestes)
        for(int i = 0; i < n and cin >> a >> fletxa >> b; ++i) {
            s.insert({a,b});
        }
        
        t = VE(n);
        for(auto& x : t) cin >> x;
        
        //Per tal que no sigui tant lent calculo els nodes de la component connexa ho faig en mòdul
        
        int i = 0;
        for(auto aux = s.begin(); aux != s.end() and i < n; ++aux) {
            int temps = t[i++];
            string origen = aux -> first;
            cout << origen << " -> ";
            
            
            
            int nodes = 0; //nombre de nodes a la component on es troba l'origen
            string primer = origen;
            string desti;
            while(desti != origen) {
                //cout << "entro" << endl;
                
                auto it = s.find(primer);
                desti = it -> second;
                primer = desti;
                ++nodes;
            }  
           
           
            //cout << "nodes de la component" << nodes << endl;
            temps = temps % nodes;
            
            
            
            while(temps--) {
                auto it = s.find(origen);
                string desti = it -> second;
                origen = desti;
            }
            
            cout << origen << endl;
        }
        
        for(int i = 0; i < 20; ++i) cout << '-';
        cout << endl;
    }   
}
