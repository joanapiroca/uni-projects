#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
#include <queue>
#include <set>
#include <map>
using namespace std;

using ps = pair<string,string>;
using VE = vector<int>;
using VD = vector<double>;
using VVE = vector<VE>;
using VS = vector<string>;
using VPS = vector<ps>;

//faig un set per poder buscar els veins amb cost log(n)
//guardo les mutacions ordenades en un vector per poder seguir l'ordre quan llegeixi els ti


int main() {
    int n;
    while(cin >> n) {
        map<string, string> s;
        
        string a, fletxa, b;
        
        //Guardo el graf en un set (els strings origen i destí de les n arestes)
        for(int i = 0; i < n and cin >> a >> fletxa >> b; ++i) {
            s.insert({a,b});
        }
        
        VD t(n);
        for(auto& x : t) cin >> x;
        
        int i = 0;
        for(auto aux = s.begin(); aux != s.end() and i < n; ++aux) {
            double temps = t[i++];
            string origen = aux -> first;
            cout << origen << " -> ";
            while(temps--) {
                auto it = s.find(origen);
                string desti = it -> second;
                origen = desti;
            }
            
            cout << origen << endl;
        }
        
        for(int i = 0; i < 20; ++i) cout << '-';
        cout << endl;
    }   
}
