#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;


int n, t;
VE v;

bool ultim(int j) { 
    while(j < n) {
        if(v[j] != 0) return false;
        ++j;
    }
    return true;
}

void escriu() {
    cout << "{";
    int k = 0;
    for(int i = 0; i < n and k < t; ++i) {
        int j = 0;
        while(j < v[i] and k < t) {
            ++j;
            ++k;
            cout << i+1 << (j == v[i] and ultim(i+1)? "" : "," );
            
        }
    }
    cout << "}" << endl;
}

void f(int i, int sum) {
	  if(sum == 0 or i == n) return escriu();
      else {
          if(i == n-1)  {
              v[i] = sum;
              f(i+1, 0);
              v[i] = 0;
          }
          else {
              for(int j = 0; j <= sum; ++j) {
                  v[i] = j;
                  f(i+1, sum-j);
            }
        }
    }
}
                  


int main() {
    cin >> n >> t;
    v = VE(n);
    if(t != 0) f(0, t);
}
