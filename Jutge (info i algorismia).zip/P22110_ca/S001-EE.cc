#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;

//VERPSIÓ MB VECTOR DE T*N ELEMENTS

int n, t, x;
VE v;

bool ultim(int j) { 
    while(j < t*n) {
        if(v[j] != 0) return false;
        ++j;
    }
    return true;
}

void escriu() {
    cout << "{";
    for(int i = 0; i < t*n and not ultim(i-1); ++i) {
		if(v[i]) cout << (i/t)+1 << (ultim(i+1)? "" : "," );
	}
    cout << "}" << endl;
}

void f(int i, int x) {
	if(x == 0) {
		for(int j = i; j < t*n; ++j) v[j] = 0;
		return escriu();
	}
	if(i+x < t*n) {
		v[i] = 0;
		f(i+1, x);
		v[i] = 1;
		f(i+1, x-1);    
	}
}

int main() {
    cin >> n >> t;
    int x = t;
    v = VE(t*n);
    f(0, x);
}
