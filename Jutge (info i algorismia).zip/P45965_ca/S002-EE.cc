#include <iostream>
#include <vector>
using namespace std;

using VE = vector<int>;

int n, u;
VE v;

void escriu() {
    for(int i = 0; i < n; ++i) cout << v[i] << " ";
    cout << endl;
}

void f(int i, int u) {
    if(i == n) {
        if (u == 0) return escriu();
        
    } 
    
    else {
        v[i] = 0;
        f(i+1, u);
        v[i] = 1;
        f(i+1, u-1);
    }
}

int main() {
    cin >> n >> u;
    v = VE(n);
    f(0, u);
}

