#include <iostream>
#include <vector>
using namespace std;

using VE = vector<int>;

int n, u;
VE v;

void escriu(int i) {
    
    for(int j = 0; j < n; ++j) {
        if(j >= i) cout << "0" << " ";
        else cout << v[j] << " ";
    }
    cout << endl;
}

void f(int i, int u) {
    if(u == 0) return escriu(i);
    if(i != n) {
        v[i] = 0;
        f(i+1, u);
        v[i] = 1;
        f(i+1, u-1);
    }
    
}

int main() {
    cin >> n >> u;
    v = VE(n);
    f(0, u);
}
