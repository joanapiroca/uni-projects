#include <iostream>
#include <vector>
using namespace std;

using VE = vector<int>;
using VC = vector<char>;

int n, v, x;
VE par;

//pos és la posició de la lletra a l'alfabet
bool vocal(int pos) { 
	if(pos == 0 or pos == 4 or pos == 8 or pos == 14 or pos == 20) return true;
	return false;
}

void escriu() {
	for(int i = 0; i < n; ++i) {
		cout << char('a' + par[i]); 
	}
	cout << endl;
}
	
	
//i és la posició de la paraula que estic omplint, falta són les vocals que em falten perque la paraula tingui v vocals
void f(int i, int voc) {	
	
	
	if(voc > v or n-v < i-voc ) return;
	if(i == n) return escriu();	
		
	for(int j = 0; j < x; ++j) {
		//La lletra és vocal
		if(vocal(j)) {
			par[i] = j;
			f(i+1, voc+1);
		}
		//La lletra és consonant
		else if(i == 0 or vocal(par[i-1])) {
				par[i] = j;
				f(i+1, voc);
		}
	}
}

int main() {
	cin >> n >> v >> x;
	//v = VE(x);
	par = VE(n);
	f(0, 0);
}
