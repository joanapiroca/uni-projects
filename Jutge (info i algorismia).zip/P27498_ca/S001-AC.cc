#include <iostream>
#include <vector>
using namespace std;

typedef vector< vector<int> > Matriu;
void transposa(Matriu& m){
    int r = m.size();
    for(int i = 0; i < r-1; ++i) {
        for(int j = i+1; j < r; ++j) swap(m[i][j], m[j][i]);
    }
}

int main () {
 
}
