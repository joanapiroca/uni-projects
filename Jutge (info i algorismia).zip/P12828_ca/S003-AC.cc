#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int> ;

int n;
VE v;  

void escriu() {
    for(int i = 0; i < n-1; ++i) cout << v[i] << " ";
    cout << v[n-1] << endl;
}

void f(int i) {
    if (i == n) return escriu();
    v[i] = 0;
    f(i+1);
    v[i] = 1;
    f(i+1);
}

int main() {    
    cin >> n;  
    v = VE(n);
    f(0);
}
