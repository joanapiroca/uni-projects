#include <iostream>
#include <cmath>
using namespace std;

int main() {
    
    cout.setf(ios::fixed);
    cout.precision(4);
    
    int n;
    cin >> n;
    
    while (n > 0) {
        int m;        
        while (cin >> m) {
            int c = m;
            double a, b, max, min, mitj;
            cin >> a;
            max = a, min = a, mitj = a;
            while (m > 1) {                                  
                cin >> b;
                if (b > max) max = b;
                if (b < min) min = b;
                mitj = mitj + b;               
                --m;
            }
        cout << min << " " << max << " " << (mitj/c) << endl;
        }
    }
}
