#include <iostream>
#include <cmath>
using namespace std;

int main() {
    
    cout.setf(ios::fixed);
    cout.precision(4);
    
    int n;
    while (cin >> n) {
         int m = n;
        double a, b, max, min, suma;
        cin >> a;
        max = a, min = a, suma = a;
        
        while (n > 1) {
            cin >> b;
            if (b > max) max = b;
            if (b < min) min = b;
            suma = suma + b;
            n = n-1;
        }
        cout << min << " " << max << " " << (suma/m) << endl;
    }
}