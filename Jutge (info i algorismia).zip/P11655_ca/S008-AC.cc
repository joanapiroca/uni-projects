#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;


int s, n, suma;
VE v, tria;

void escriu() {
    cout << "{";
    bool primer = true;
    for(int i=0; i < n; ++i) {
        if(tria[i] == 1) {
            cout << (primer ? "": ",") << v[i];
            primer = false;
        }
    }
    cout << "}" << endl;
}


void f(int i, int sum, int resta) {
    
    if( i == n or sum > s or resta < s - sum) { //així em surten els casos 6,0,0...
        if(sum == s) return escriu();
        return;
    }
    
    tria[i] = 0;
    f(i+1, sum, resta - v[i]);
    
    if(sum < s or v[i] == 0) {
        tria[i] = 1;
        f(i+1, sum + v[i], resta - v[i]);
    }
}


int main() {
    cin >> s >> n;
    v = VE(n);
    tria = VE(n);
    suma = 0;
    for (int i = 0; i < n; ++i) {
        cin >> v[i];
        suma += v[i];
    }
    f(0, 0, suma);
}


