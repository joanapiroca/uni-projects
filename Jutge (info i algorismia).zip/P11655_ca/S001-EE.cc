#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;

//Està millorat del que el jutge m'accepta, perquè no funciona????

int s, n;
VE v;
VE tria;

void escriu() {
    for(int i=0; i < n; ++i) {
        if(tria[i] == 1 ) cout << v[i] << ",";
    }
    cout << endl;
}


void f(int i, int sum, int resta) {
    if(sum == s) return escriu();
    if(sum > s or i == n or resta + sum < s) return;
    
    tria[i] = 1;
    f(i+1, sum + v[i], resta - v[i]);
    tria[i] = 0;
    f(i+1, sum, resta);
}


int main() {
    cin >> s >> n;
    v = VE(n);
    tria = VE(n);
    for(int& x : v) cin >> x;
    
    int res = 0;
    for(int j=0; j < n; ++j) res += v[j];
    f(0, 0, res);
}