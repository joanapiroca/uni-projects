#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;

//Està millorat del que el jutge m'accepta, perquè no funciona????

int s, n;
VE v;
VE tria;

bool ultim(int j) {
    for(int i=j+1; i < n; ++i) {
        if(tria[i]) return false;
    }
    return true;
}

void escriu() {
    cout << "{";
    for(int i=0; i < n; ++i) {
        if(tria[i]) cout << v[i] << (ultim(i) ? "":",");
    }
    cout << "}" << endl;
}


void f(int i, int sum, int resta) {
    
    if( i == n or sum > s or (resta + sum) < s) { //així em surten els casos 6,0,0...
        if(sum == s) return escriu();
        return;
    }
    
    tria[i] = 0;
    f(i+1, sum, resta);
    
    if(sum < s or v[i] == 0) {
        tria[i] = 1;
        f(i+1, sum + v[i], resta - v[i]);
    }
}


int main() {
    cin >> s >> n;
    v = VE(n);
    tria = VE(n);
    for (int i = 0; i < n; ++i) {
        cin >> u[i];
        suma += u[i];
    }
    f(0, 0, res);
}
