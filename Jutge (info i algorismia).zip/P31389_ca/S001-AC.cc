#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;


int f, c;
VE v, col;


void escriu() {
    for(int i = 0; i < f; ++i){
		for(int j = 0; j < c; ++j) {
			if(v[i] == j) cout << "R";
			else cout << ".";
		}
		cout << endl;
	}
	cout << endl;
}


void fun(int i) {
	if(i == f)return escriu();
	for(int j = 0; j < c; ++j) {
		if(not col[j]){
			v[i] = j; //marco la columna on poso la torre
			col[j] = 1; //marco que la columna està ocupada
			fun(i+1);
			col[j] = 0; //pel backtracking
		}
	}
}


int main() {
    cin >> f >> c;
    v = VE(f); //marca columna on poso la torre de fila i 
    col = VE(c,0); //marca columnes ocupades
    fun(0);
}

// col és de boolears i v d'enters;
