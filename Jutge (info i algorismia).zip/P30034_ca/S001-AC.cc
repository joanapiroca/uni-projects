#include <iostream>
#include <stdio.h>
#include <vector>
#include <algorithm>
using namespace std;

bool son_complementaris(int x, int y, int b) {
    if((x == 0 and y != 0) or (x != 0 and y == 0)) return false;
    if(x==0 and y == 0) return true;
    if((x+y)%b != b-1) return false;
    
    return son_complementaris(x/b, y/b, b);
}

int main() {
   int x, y, b;
   while(cin >> x >> y >> b) {
       cout << son_complementaris(x, y, b) << endl;
   }
}
