#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

//BOMBETES

using VE = vector<int>;
using VEE = vector<VE>;

int n, m, res;
VE fil, col;
VEE a;  

//entrada i, j de la matriu a;
void f(int i, int j) {
    cout << "a" << endl;
    if(j == m) {
       j=0;
       ++i;
    }
        
        
    if(i == n) {
        ++res;
        return;
    }
    for(int x: fil) {
        if(x < 0) return;
    }
    for(int x: col) {
        if(x < 0) return;
    }
    
    
    if(a[i][j] == -1) {        
        a[i][j] = 0;
        f(i, j+1);
        
        a[i][j] = 1;
        --fil[i];
        --col[j];
        f(i, j+1);
    }   
    else f(i, j+1);
}



int main() {
    while(cin >> n >> m) {
        res = 0; //guardo el resultat
        fil = VE(n); //fil[i] = numero de bombetes per encendre a la fila i
        col = VE(m); //col[i] = numero de bombetes per encendre a la col i
        a = VEE(n, VE(m, -1)); 
        
        char s;
        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < m; ++j) {
               cin >> s;
               if(s == 'X') a[i][j] = 0;
               if(s == 'O') a[i][j] = 1;
            //sino es queda el -1 que signifa que es pot triar l'estat
            }
        }
        
        for(int& x: fil) cin >> x;
        for(int& x: col) cin >> x;
        
        //actualitzo les restriccions en els vector fil i col
        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < m; ++j) {
                if(a[i][j] == 1) {
                    --fil[i];
                    --col[i];
                }
            }
        }
        
        f(0,0);
        cout << res << endl;
        
    }
}

