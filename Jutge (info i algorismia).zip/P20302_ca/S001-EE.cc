#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
#include <queue>
#include <set>
#include <map>
using namespace std;

using ps = pair<string,string>;
using VE = vector<int>;
using VL = vector<long long>;
using VD = vector<double>;
using VVD = vector<VD>;
using VVE = vector<VE>;
using VS = vector<string>;
using VPS = vector<ps>;

int n, k;
VD prob;
VVD m; //matriu de recurrència;

//probabilitat de treure j cares amb les i primeres monedes
double f(int i, int j) {
    if(i < 0 or j < 0) return 1.0;
    
    double& res = m[i][j];
    
    if(res != -1) return res;
    
    //Probabilitat de treure 0 cares amb cap moneda és 1
    //Si afegeixo monedes s'hi afeeix la probabilitat de que cadascuna no sigui cara 
    if(i == 0 and j == 0) return res = 1.0;
    if(i != 0 and j == 0) return res = f(i-1, j)*(1-prob[i]);
    if(i == 0 and j != 0) return res = f(i, j-1);
    
    return res = f(i, j-1)*(1-prob[i]) + f(i-1, j)*prob[i];
    
}

int main() {
    cout.setf(ios::fixed);
    cout.precision(4);
    
    while( cin >> n >> k){
        prob = VD(n);
        for(auto& x : prob) cin >> x;
        
        m = VVD(n+1, VD(k+1, -1));
        double resultat = f(n+1, k+1);
        cout << resultat << endl;
    }
}
