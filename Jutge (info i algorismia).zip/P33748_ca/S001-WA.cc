#include <iostream>
#include <vector>
using namespace std;

using VE = vector<int>;
using VS = vector<string>;

int n, u;
VE v;
VS par;

bool ultim(int i) {
    while(i < n) {
        if(v[i]) return false;
        ++i;
    }
    return true;
}

void escriu(int i) {
    int x = i;
    while(x < n) {
            v[x] = 0;
            ++x;
    }
    cout << "{" ;
    for(int i = 0; i < n; ++i) {
        if(v[i]) cout << par[i] << (ultim(i+1) ?  "" : ","); //com veure que és l'últim element del subconjunt (= últim 1)
    }
    cout << "}" << endl;
}


void f(int i, int u) {
    if(u == 0) return escriu(i);
    if(i+u < n) {
        v[i] = 0;
        f(i+1, u);
        v[i] = 1;
        f(i+1, u-1);
    }
}

int main() {
    cin >> u >> n;
    v = VE(n);
    par = VS(n);
    for (string& s : par) cin >> s; 
    f(0, u);
}