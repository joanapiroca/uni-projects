#include <iostream>
#include <vector>
#include <set>
#include <sstream>
using namespace std;

using VE = vector<int>;

int n, d;
VE vist, per;

void escriu() {
	for(int i = 0; i < n; ++i) cout << char('A' + per[i]);
	cout << endl;
}


void f(int i) {
	if(i == n) return escriu();
	
	for(int j = 0; j < n ; ++j) {
		
		if(not vist[j] and (i <= j-d or i >= j+d)) {
			per[i] = j;
			vist[j] = true;
			f(i+1);
			
			vist[j] = false;	
		}	
	}
}

int main() {
	cin >> n >> d;
	vist = VE(n, false);
	per = VE(n);
	f(0);
}
