#include <iostream>
#include <vector>
#include <math.h>
#include <algorithm>
using namespace std;

void omple_uns(vector<string>& v, int i, int j, int n, int m) {
    if(n == 1) {
        if(j == 0) v[0][j+1] = 'X';
        if(j == m-1) v[0][j-1] = 'X';
        else {
            v[0][j+1] = 'X';
            v[0][j-1] = 'X';
        }
    }
    if(m == 1) {
        if(i == 0) v[i+1][0] = 'X';
        if(i == n-1) v[i-1][0] = 'X';
        else {
            v[i-1][0] = 'X';
            v[i+1][0] = 'X';
        }
    }
}


void omple(vector<string>& v,int i,int j,int n,int m) {
    if(i == 0 and j == 0) {
        v[i][j+1] = 'X';
        v[i+1][j] = 'X';
    }
    else if(i == 0 and j > 0 and j < m-1) {
        v[i+1][j] = 'X';
        v[i][j+1] = 'X';
        v[i][j-1] = 'X';
    }
    else if(i == 0 and j == m-1) {
        v[i][j-1] = 'X';
        v[i+1][j] = 'X';
    }
    else if(j == m-1 and i > 0 and i < n-1) {
        v[i-1][j] = 'X';
        v[i+1][j] = 'X';
        v[i][j-1] = 'X';
    }
    else if(i == n-1 and j == m-1) {
        v[i-1][j] = 'X';
        v[i][j-1] = 'X';
    }
    else if(i == n-1 and j > 0 and j < m-1) {
        v[i][j+1] = 'X';
        v[i][j-1] = 'X';
        v[i-1][j] = 'X';
    }
    else if(i == n-1 and j == 0) {
        v[i-1][j] = 'X';
        v[i][j+1] = 'X';
    }
    else if(i > 0 and i < n-1 and j == 0) {
        v[i-1][j] = 'X';
        v[i+1][j] = 'X';
        v[i][j+1] = 'X';
    }
    else {
        v[i+1][j] = 'X';
        v[i-1][j] = 'X';
        v[i][j+1] = 'X';
        v[i][j-1] = 'X';
    }
}

void treu(vector<string> v,int n,int m) {
    for(int i = 0; i < n; ++i) cout << v[i] << endl;
}

bool acabat(vector<string> v, int n, int m){
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < m; ++j) {
            if(v[i][j] != 'X') return false;
        }
    }
    return true;
}

int main() {
    int n, m;
    while(cin >> n >> m) {
        string s;
        vector<string> v(n);
        for(int i = 0; i < n; ++i) cin >> v[i];
        treu(v, n, m);
        cout << endl;
        
        vector<string> nou(n);
        for(int i = 0; i < n; ++i) nou[i] = v[i];
        
        while(not acabat(nou, n, m)) {
            
            for(int i = 0; i < n; ++i) {
                for(int j = 0; j < m; ++j) {
                    if(v[i][j] == 'X' and n == 1) omple_uns(nou, i, j, n, m);
                    if(v[i][j] == 'X' and m == 1) omple_uns(nou, i, j, n, m);
                    if(v[i][j] == 'X' and n != 1 and m != 1) omple(nou, i, j, n, m);
                }
            }
            
            
            for(int i = 0; i < n; ++i) v[i] = nou[i];
            treu(nou, n, m);
            cout << endl;
        }
        cout << "----------" << endl;
    }
    
}

