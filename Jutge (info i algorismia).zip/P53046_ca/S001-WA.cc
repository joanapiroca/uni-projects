#include<iostream>
#include<vector>
using namespace std;

using VE = vector<int>;


int n;
VE v, perm;

void escriu() {
    cout << "(";
    for(int i = 0; i < n; ++i) cout << perm[i] + 1 << (i == n-1 ? "" : ",");
    cout << ")" << endl;
}


void f(int i, int it) { //i es la posició i cicle indica si he trobat algun cicle
	if(it == n)return escriu();

	for(int j = 0; j < n; ++j) {
		if(v[j] == 0 and i != j and perm[j] == -1) { //si el nombre j encara no ha sortit
			perm[i] = j; //el poso a la posició i
			v[j] = 1;
			f(j, ++it); //omplo la següent posició
			v[j] = 0; // pel backtracking
			perm[i] = -1;
		}
	}
}


int main() {
    cin >> n;
    v = VE(n,0); //marca els nombres que ja apareixen a la permutacio
    perm = VE(n, -1); //guarda la permutació
    f(0, 0);
}


