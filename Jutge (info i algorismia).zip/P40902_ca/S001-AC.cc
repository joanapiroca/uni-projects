#include <iostream>
#include <vector>
#include <map>
using namespace std;

using MSI = map<string, int>;

MSI m;
string nom, operacio;


int main() {
	
	while(cin >> nom >> operacio) {
		auto it = m.find(nom);
		
		if(operacio == "enters") {
			if(it == m.end()) m[nom] = 0;
			else cout << nom << " is already in the casino" << endl;
		}
		
		if(operacio == "leaves") {
			if(it == m.end()) cout << nom << " is not in the casino" << endl;	
			else {
				cout << nom << " has won " << it -> second << endl;
				m.erase(it);
			}
		}
		if(operacio == "wins") {
			int x;
			cin >> x;
			
			if(it == m.end()) cout << nom << " is not in the casino" << endl;	
			else it -> second += x;
		}
	}
	
	for(int i = 0; i < 10; ++i) cout << '-';
	cout << endl;
	
	for(auto it = m.begin(); it != m.end(); ++it) cout << it -> first << " is winning " << it -> second << endl;
}
		
