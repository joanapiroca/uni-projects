#include <iostream>
#include <vector>
using namespace std;

bool es_palindrom(const string& s) {
    int left = 0, right = s.size() -1;
    while (left < right and s[left] == s[right]) {
        ++left;
        --right;
    }
    if (left == right or left == right+1) return true;
    else return false;
}

int main() {
    string s;
    cin >> s;
    cout << es_palindrom(s) << endl; 
}
