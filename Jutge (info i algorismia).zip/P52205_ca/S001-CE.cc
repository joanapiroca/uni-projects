#include <vector>
#include <iostream>
using namespace std;

void ordena_per_fusio(vector<double>& v) {
    if (v.size() > 0) {
        vector<double> v1((int)v.size()/2 +1);
        vector<double> v2((int)v.size()/2);
        ordena_per_fusio(v1);
        ordena_per_fusio(v2);
        fusio(v, v1, v2);
    }
}

void fusio(vector<double>& v, vector<double>& v1, vector<double>& v2) {
    vector<double> aux;
    int i = 0, j = 0;
    
    while(i < v1.size() and j < v2.size()) {
        if(v1[i] <= v2[j]) aux.pop_back(v1[i]); ++i;
        else { 
            aux.pop_back(v2[j]);
            ++j;
        }
    }
    
    while(i < v1.size()) {
        aux.pop_back(v1[i]); ++i;
    }
    
    while( j < v2.size()) {
         aux.pop_back(v2[j]);
        ++j;
    }
    
    for(int k = 0; k < v.size(); ++k) v[k] = aux[k];
}

int main() {
   
}
