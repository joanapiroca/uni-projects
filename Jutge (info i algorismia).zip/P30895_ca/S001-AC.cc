#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
#include <queue>
using namespace std;

using p = pair<int,int>;
using VE = vector<int>;
using VVE = vector<VE>;

int n;
VVE m;  //matriu de costs
VVE dist;

VE df = {1, -1, 0, 0};
VE dc = {0,  0, 1,-1};



//Dijkstra des del mig (n/2, n/2) per arribar a la perifèria;
int f() {
    priority_queue<pair<int,p>> q;    //primer el cost, després les coordenades a la matriu (i,j)
    q.push({-m[n/2][n/2] ,{n/2, n/2}});
    dist[n/2][n/2] = m[n/2][n/2];
    
    while(not q.empty()) {
        auto aux = q.top(); q.pop();
        int d = -aux.first;
        int x = aux.second.first;
        int y = aux.second.second;
        
        if(d == dist[x][y]) {   //m'asseguro que no és un element acumulat a la cua i no és el mínim;
            if(x == 0 or x == n-1 or y == 0 or y == n-1) return d; //he arribat a la perifèria
        
            for(int k = 0; k < 4; ++k) {
                int xf = x + df[k];
                int yf = y + dc[k];
                int c = m[xf][yf];
                
                if(dist[xf][yf] == -1 or (d+c < dist[xf][yf])) {
                    q.push({-(d+c), {xf,yf}});
                    dist[xf][yf] = d+c;
                }
            }
        }
    }
    return -1; //No hauria d'entrar aquí en cap cas ja que sempre hi ha un camí mínim (el "graf" és connex)  
}



int main() {
    while(cin >> n) {
        m = VVE(n, VE(n));
        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < n; ++j) cin >> m[i][j];
        }
        
        dist = VVE(n, VE(n, -1));
        int min = f(); 
        cout << min << endl;
    }        
}
