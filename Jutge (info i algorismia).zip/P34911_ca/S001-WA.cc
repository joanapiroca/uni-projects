#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;

struct Casella {
         string e; // especie
         int v;    // vida
};

bool estable(const vector<vector<Casella>> & a,const int n,const int m) {
    int x = a[0][0].v;
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < m; ++j) {
            if(a[i][j].v != x) return false;
        }
    }
    return true;
}

int mitjana(const vector<vector<Casella>> & a,const int i,const int j, const int n, const int m) {
    int mitjana = a[i][j].v;
    int nin = 1;
    
    string especie = a[i][j].e;
    
    if(i-1 >= 0) {
        if(a[i-1][j].e != especie) {
            mitjana = mitjana + a[i-1][j].v;
            ++nin;
        }
    }
    if(i+1 < n) {
        if(a[i+1][j].e != especie) {
            mitjana = mitjana + a[i+1][j].v;
            ++nin;
        }
    }
    if(j-1 >= 0) {
        if(a[i][j-1].e != especie) {
            mitjana = mitjana + a[i][j-1].v;
            ++nin;
        }
    }
    if(j+1 < m) {
        if(a[i][j+1].e != especie) {
            mitjana = mitjana + a[i][j+1].v;
            ++nin;
        }
    }
    
    return (mitjana/nin);
}

bool acabat(const vector<vector<Casella>> & a, const vector<vector<Casella>> & copia, int n, int m) {
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < m; ++j) {
            if(a[i][j].v != copia[i][j].v) return false;
        }
    }
    return true;
}

int main() {
    int n, m;
    while(cin >> n >> m) {
        vector<vector<Casella>> a(n, vector<Casella> (m));
        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < m; ++j) cin >> a[i][j].e >> a[i][j].v;
        }
        
        bool fi = false;
        while(not estable(a, n, m) and not fi) {
            vector<vector<Casella>> copia(n, vector<Casella> (m));
            copia = a;
            
            for(int i = 0; i < n; ++i) {
                for(int j = 0; j < m; ++j) {
                    copia[i][j].v = mitjana(a, i, j, n, m);
                }
            }
            
            fi = acabat(a, copia, n, m);
            
            for(int i = 0; i < n and not fi; ++i) {
                for(int j = 0; j < m; ++j) cout << copia[i][j].e << " " << copia[i][j].v << "  " ;
                cout << endl;
            }
            cout << endl;
            
            
            a = copia;
        }
        cout << "****************************************" << endl;
    }
    
}

