#include <iostream>
#include <cmath>
using namespace std;

int factorial_doble(int n) {
    if (n == 0 or n == 1) return 1;
    return n*factorial(n-2);
}
int main (){
    
}
       
