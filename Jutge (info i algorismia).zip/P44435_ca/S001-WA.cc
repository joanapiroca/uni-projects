#include <iostream>
#include <cmath>
using namespace std;

bool fibonacci(int a) {
    if (a == 1 or a == 2) return true;
    int x = 1, y = 2, fib;
    while (fib < a) {
        fib = x + y;
        x = y;
        y = fib;
    }
    if (fib == a) return true;
    else return false;         
}

bool seguent(int a, int b) {
    int fib, x = 1, y = 2;    
    while (fib < b) {
        fib = x + y;
        x = y ;
        y = fib;       
    }    
    if (x == a) return true;
    else return false;
}
     
int main () {
    int a, aux;
    while (cin >> a) {
        bool supfib = true;
        while (a != 0) {
            if (fibonacci(a) == true and a != aux) aux = a;
            cin >> a;
            if (fibonacci(a) and a != aux) {
                if (seguent(aux, a) == false) supfib = false;
                aux = a;
            } 
        }
        if (supfib == false) cout << "yes" << endl;
        else cout << "no" << endl;
    }
}
            
        




