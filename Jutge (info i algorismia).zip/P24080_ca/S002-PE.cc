#include <iostream>
#include <cmath>    
using namespace std;

int main() {
    int n;
    
    int j = 0;
    int i = 0;
    
    while (cin >> n){
        cout << endl;
        while (j < n) {
            while(i < n) {
                cout << n;
                i = i + 1;
            }
        cout << endl;
        j = j + 1;
        i = 0;
        }
    j = 0;
    }
    
}
