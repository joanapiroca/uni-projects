#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

using VE = vector<int>;
using VVE = vector<VE>;
using p = pair<int,int>;
using VP = vector<p>;
using VVP = vector<VP>;
using VS = vector<string>;
using VVC = vector<string>;

int n,m;
VVP g;
VE dist;

//Cerca en amplada prioritzant les arestes de cost mínim.
//no paro fins que es buida la queue, si ja hi he passat, comparo costos i em quedo el menor

void f() {
	queue<p> q;
	q.push({0,0});
	dist[0] = 0; 
	//dist del 0?
	
	while(not q.empty()) {
		auto aux = q.front(); q.pop();
		int x = aux.first;
		int d = aux.second;
		
		for(auto arc : g[x]) {
			int y = arc.first;
			int c = arc.second;
			
			if(dist[y] == -1 or (dist[y] > d+c)) {
				dist[y] = c+d;
				q.push({y,c+d});
			}
		}
	}
	
	return;
}


int main() {
	while(cin >> n >> m) {
		g = VVP(n);
		int u, v, c;
		while(m--) {
			cin >> u >> v >> c;
			g[u].push_back({v,c});
		}
		dist = VE(n, -1);
		f();
		
		for(int i = 0; i < n; ++i) {
			if(dist[i] == -1) cout << i << " : no" << endl;
			else cout << i << " : " << dist[i] << endl;		
		}
	}
}
