setwd("C:/Users/Inmaculada/Desktop/Universitat/3r UPC/2n quadri/Estadistica/Entregables/Entregable 5")
dd <- read.csv2("Dades_Inaki.csv")
library(car)
n <- dim(dd)[1]


M1<-lm(Density~Neck+Chest+Abdomen+Thigh+Biceps,dd)

#Apartats 1-4
print(summary(M1), digits = 8)
#Apartat 1: Prendre el Multiple R-squared
#Apartat 2: Prendre el Residual standard error i elevar-lo al quadrat
#Apartat 3: Prendre el Estimate del Intercept
#Apartat 4: Prendre el F-statistic

#Apartats 5-6
print(Anova(M1), digits = 8)
#Apartat 5: valor del Pr(>F) de la primera variable
#Apartat 6: valor de Sum Sq dels Residuals

#Apartat 7
vif(M1)
#Apartat 7: valor maxim dels que dona la funcio vif

#Apartat 8
M2<-lm(Density~Neck+Abdomen,dd)
print(summary(M2), digits = 8)
#Apartat 8: anar traient la variable amb Pr(|t|) mes alta fins que totes tinguin un valor menor a 0.05

#Apartat 9
dd$res <- rstudent(M2)
aux <- subset(dd, abs(rstudent(M2)) > 2)
(percentatge <- dim(aux)[1]/n)

#Apartat 10
print(max(abs(dffits(M2))), digits = 8)

#Apartats 11-12
mostra <- data.frame(Neck=37.8, Abdomen = 90.6)
print(predict(M2, mostra, interval = "prediction"), digits = 8)
#Apartat 11: prendre el lwr
#Apartat 12: prendre el upr

#Apartats 13-14
print(predict(M2, mostra, interval = "confidence"), digits = 8)
#Apartat 13: prendre el lwr
#Apartat 14: prendre el upr

#Apartats 15 i 17
M3<-lm(Density~Diet,dd,contrasts=list(Diet="contr.treatment"))
print(summary(M3), digits = 8)
#Apartat 15: prendre valor del intercept
#Activitat 17: prendre valor multiple R-squared

#Apartats 16, 18 i 19
M4<-lm(Density~Diet,dd,contrasts=list(Diet="contr.sum"))
print(summary(M4), digits = 8)
#Apartat 16: prendre valor del intercept
#Apartat 18: prendre el F-statistic
#Apartat 19: prendre el residual standard error

#Apartats 20 i 21
library(emmeans)
confint(emmeans(M4,~Diet))[,5:6]
#Apartat 20: prendre el valor 1 lower.CL
#Apartat 21: prendre el valor 1 upper.CL

#Apartat 22
emm <- emmeans(M4,~Diet, adjust = "Tukey")
cld(emm, alpha = 0.05)
#Apartat 22: mirar numero de grups diferents a .group
