#Lectura de dades
frequencies <- c(3, 11, 21, 30, 37, 42, 46, 45, 37, 46, 40, 38, 20, 24, 28, 9, 13, 12, 4, 13, 11, 4, 4, 4, 6, 2, 1, 4, 2, 0)
tab <- data.frame(value=c(0:29), freq=frequencies)
vec <- data.frame(rep(tab$value, tab$freq))

#Apartat A
n <- dim(vec)[1]
m1 <- sum(vec)/n
m2 <- sum(vec^2)/n
#Questio 1
pmm <- m1/(m2-m1*m1)
print(pmm, digits = 8)
#Questio 2
rmm <- m1*m1/(m2-m1-m1*m1)
print(rmm, digits = 8)
#Questio 3
mumm <- m1
print(mumm, digits = 8)
#Questio 4
sigma2mm <- m2-m1*m1
print(sigma2mm, digits = 8)
#Questio 5
valorsFfr<-cumsum(frequencies/n)
Ffr <- data.frame(x=c(0:29), valor=valorsFfr)
valorsFmm <-cumsum((gamma(rmm+c(0:29))/(gamma(c(0:29)+1)*gamma(rmm)))*(pmm^rmm)*(1-pmm)^(c(0:29)))
Fmm <- data.frame(x=c(0:29), valor=valorsFmm)
plot(Ffr, col = "blue")
par(new=TRUE)
plot(Fmm, col = "red")
maximmm <- max(abs(valorsFfr-valorsFmm))
print(maximmm, digits = 8)
#Questio 6
print("Binomial negativa")

#Apartat B
menyslogL <- function(X) {
  p <- X[1]
  r <- X[2]
  -(sum(lgamma(r+vec))-sum(lgamma(1+vec))-n*lgamma(r)+n*r*log(p)+sum(vec)*log(1-p))
}
parammv <- nlm(menyslogL,c(0.3,4), ndigit = 20, gradtol = 1e-10, steptol = 1e-10)$estimate
#Questio 7
pmv <- parammv[1]
print(pmv, digits = 8)
#Questio 8
rmv <- parammv[2]
print(rmv, digits = 8)
#Questio 9
mumv <- rmv*(1-pmv)/pmv
print(mumv, digits = 8)
#Questio 10
sigma2mv <- rmv*(1-pmv)/(pmv^2)
print(sigma2mv, digits = 8)
#Questio 11
valorsFmv <-cumsum((gamma(rmv+c(0:29))/(gamma(c(0:29)+1)*gamma(rmv)))*(pmv^rmv)*(1-pmv)^(c(0:29)))
Fmv <- data.frame(x=c(0:29), valor=valorsFmv)
plot(Ffr, col = "blue")
par(new=TRUE)
plot(Fmv, col = "red")
maximmv <- max(abs(valorsFfr-valorsFmv))
print(maximmv, digits = 8)
#Questio 12
print("S?, sempre")

#Apartat C
rpost <- 4
exp1 <- 0
exp2 <- -0.5
alfa <- rpost*n+1+exp1
beta <- sum(vec)+1+exp2
#Questio 13
espppost <- alfa/(alfa+beta)
print(espppost, digits = 8)
#Questio 14
varppost <- alfa*beta/(((alfa+beta)^2)*(alfa+beta+1))
print(varppost, digits = 8)
#Questio 15
espX <- rpost*beta/(alfa-1)
print(espX, digits = 8)
#Questio 16
varX <- rpost*(alfa+beta-1)*beta/((alfa-1)*(alfa-2)) + rpost^2*beta*(beta+1)/((alfa-1)*(alfa-2)) - (rpost*beta/(alfa-1))^2
print(varX, digits = 8)
