a <- -1.7

#Apartat A
espX <- 2.8
espinvX <- 0.43
f1 <- function(y) besselK(2*(a+1)*y/(espX-y^2*espinvX), a+2)/besselK(2*(a+1)*y/(espX-y^2*espinvX), a+1) *y- espX
curve(f1, from = 2, to = 5)
eta <-uniroot(f1, lower = 2.6, upper = 5, extendInt="yes", tol = 1e-9)$root
lambda <- 2*(a+1)*eta/(espX-eta^2*espinvX)
#Questio 1
print(lambda, digits = 8)
#Questio 2
print(eta, digits = 8)
#Questio 3
VarX <- eta^2*(besselK(lambda, a+1)*besselK(lambda, a+3) - besselK(lambda, a+2)^2)/(besselK(lambda, a+1)^2)
print(VarX, digits = 8)
#Questio 4
VarinvX <- -4*(a+1)/(lambda^2*eta^2) + (1/(eta^2))*(besselK(lambda, a+1)*besselK(lambda, a+3) - besselK(lambda, a+2)^2)/(besselK(lambda, a+1)^2)
print(VarinvX, digits = 8)
#Questio 5
covXinvX <- (-1/lambda)*(2*besselK(lambda, a+1)*besselK(lambda, a+2)-lambda*besselK(lambda, a+3)*besselK(lambda, a+1)+lambda*besselK(lambda, a+2)^2)/(besselK(lambda, a+1)^2)
print(covXinvX, digits = 8)

#ApartatB
mitjaX <- 2.782419
mitjainvX <- 0.437309
n <- 74
f2 <- function(y) besselK(2*(a+1)*y/(mitjaX-y^2*mitjainvX), a+2)/besselK(2*(a+1)*y/(mitjaX-y^2*mitjainvX), a+1)*y - mitjaX
curve(f2, from = 2, to = 5)
etamv <-uniroot(f2, lower = 2.6, upper = 5, extendInt="yes", tol = 1e-9)$root
lambdamv <- 2*(a+1)*etamv/(mitjaX-etamv^2*mitjainvX)
#Questio 6
print(lambdamv, digits = 8)
#Questio 7
print(etamv, digits = 8)
#Questio 8
I11 <- n*(etamv^2*(besselK(lambdamv, a+1)*besselK(lambdamv, a+3) - besselK(lambdamv, a+2)^2)/(besselK(lambdamv, a+1)^2))
print(I11, digits = 8)
#Questio 9
I22 <- n*(-4*(a+1)/(lambdamv^2*etamv^2) + (1/(etamv^2))*(besselK(lambdamv, a+1)*besselK(lambdamv, a+3) - besselK(lambdamv, a+2)^2)/(besselK(lambdamv, a+1)^2))
print(I22, digits = 8)
#Questio 10
I12 <- n*((-1/lambdamv)*(2*besselK(lambdamv, a+1)*besselK(lambdamv, a+2)-lambdamv*besselK(lambdamv, a+3)*besselK(lambdamv, a+1)+lambdamv*besselK(lambdamv, a+2)^2)/(besselK(lambdamv, a+1)^2))
print(I12, digits = 8)

#Apartat C
#Questio 11
CRLB1 <- I11/n^2
print(CRLB1, digits = 8)
#Questio 12
CRLB2 <- I22/n^2
print(CRLB2, digits = 8)
#Questio 13
Varlambdamv <- (1/(I11*I22-I12^2))*(etamv^2*I22-2*I12+I11/(etamv^2))
aux <- qnorm(p = 0.975, mean = 0, sd = 1)
extreminflambda <- lambdamv - aux*sqrt(Varlambdamv)
extremsuplambda <- lambdamv + aux*sqrt(Varlambdamv)
print(extreminflambda, digits = 8)
print(extremsuplambda, digits = 8)
#Questio 14
Varetamv <- (1/((I11*I22-I12^2)*lambdamv^2))*(etamv^4*I22+2*I12*etamv^2+I11)
extreminfeta <- etamv - aux*sqrt(Varetamv)
extremsupeta <- etamv + aux*sqrt(Varetamv)
print(extreminfeta, digits = 8)
print(extremsupeta, digits = 8)
