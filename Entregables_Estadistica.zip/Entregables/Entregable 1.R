#Activitats 1-6
setwd("~/KOLMOGOROV/3r/Estadistica/Entregable 1")
dd<-read.csv2("Dades.csv")
dd$BMI<-dd$Pes/(dd$H/100)^2
dd$IM<-dd$D2/dd$D4
dd$CEdat<-cut(dd$Edat,c(0,26,200),label=c("Joves","Grans"),right=T)
library(tables)
print(tabular(IM*CEdat~Sexe*(mean+var+sd),data=dd), digits=5)

#Activitats 7 i 8
mu <- 67.802
sigma2 <- 157.676
MGran <- subset(dd, Sexe == "M" & CEdat == "Grans")
n <- dim(MGran)[1]
(mitjana <- mean(MGran$Pes))
extesq<-qt(0.005, df = n-1)*sd(MGran$Pes)/sqrt(n)+mu
print(extesq, digits=5)
extdre<-qt(0.995, df = n-1)*sd(MGran$Pes)/sqrt(n)+mu
print(extdre, digits=5)

#Activitat 9
val <- abs(mitjana-mu)*sqrt(n)/sd(MGran$Pes)
(proba <- 2*(1-pt(val, df = n-1)))

#Activitats 10 i 11
(varianca <- var(MGran$Pes))
extesq1<-qchisq(0.005, df = n-1)*sigma2/(n-1)
print(extesq1, digits=5)
extdre1<-qchisq(0.995, df = n-1)*sigma2/(n-1)
print(extdre1, digits=5)

#Activitat 12
val1 <-((n-1)/sigma2)*(sigma2+abs(sigma2-varianca))
val2 <-((n-1)/sigma2)*(sigma2-abs(sigma2-varianca))
(proba2 <- 1-pchisq(val1, df = n-1)+pchisq(val2, df = n-1))
