setwd("C:/Users/Inmaculada/Desktop/Universitat/3r UPC/2n quadri/Estadistica/Entregables/Entregable 4")
dd<-read.csv2("Dades_Inaki.csv")
GC <- subset(dd, Grupo == "GC")
GE <- subset(dd, Grupo == "GE")
n <- dim(GC)[1]
#Activitat 1
var.test(GE$AnEvol, GC$AnEvol, ratio = 1, alternative = "two.sided", conf.level = 0.95)
print(t.test(GE$AnEvol, GC$AnEvol, mu = 0, alternative = "two.sided", paired = FALSE, var.equal = TRUE, conf.level = 0.95)$statistic, digits = 8)
#Activitat 2
print(t.test(GE$AnEvol, GC$AnEvol, mu = 0, alternative = "two.sided", paired = FALSE, var.equal = TRUE, conf.level = 0.95)$p.value, digits = 8)
#Activitat 3
a11 <- dim(subset(GC, EstCiv == "S"))[1]
a12 <- dim(subset(GC, EstCiv == "O"))[1]
a21 <- dim(subset(GE, EstCiv == "S"))[1]
a22 <- dim(subset(GE, EstCiv == "O"))[1]
x = matrix(c(a11, a21, a12, a22), ncol = 2)
print(chisq.test(x, correct = FALSE)$statistic, digits = 8)
#Activitat 4
print(chisq.test(x, correct = FALSE)$p.value, digits = 8)

#Activitat 5
var.test(GE$VelocProc_B, GC$VelocProc_B, ratio = 1, alternative = "two.sided", conf.level = 0.95)
print(t.test(GE$VelocProc_B, GC$VelocProc_B, mu = 0, alternative = "two.sided", paired = FALSE, var.equal = TRUE, conf.level = 0.95)$statistic, digits = 8)
#Activitat 6
print(t.test(GE$VelocProc_B, GC$VelocProc_B, mu = 0, alternative = "two.sided", paired = FALSE, var.equal = TRUE, conf.level = 0.95)$p.value, digits = 8)
#Activitat 7
var.test(GE$VelocProc_P, GC$VelocProc_P, ratio = 1, alternative = "two.sided", conf.level = 0.95)
print(t.test(GE$VelocProc_P, GC$VelocProc_P, mu = 0, alternative = "two.sided", paired = FALSE, var.equal = FALSE, conf.level = 0.95)$statistic, digits = 8)
#Activitat 8
print(t.test(GE$VelocProc_P, GC$VelocProc_P, mu = 0, alternative = "two.sided", paired = FALSE, var.equal = FALSE, conf.level = 0.95)$p.value, digits = 8)

#Activitat 9
var.test(GC$VelocProc_P, GC$VelocProc_B, ratio = 1, alternative = "two.sided", conf.level = 0.95)
print(t.test(GC$VelocProc_P, GC$VelocProc_B, mu = 0, alternative = "two.sided", paired = TRUE, var.equal = FALSE, conf.level = 0.95)$conf.int[1][1], digits = 8)
#Activitat 10
print(t.test(GC$VelocProc_P, GC$VelocProc_B, mu = 0, alternative = "two.sided", paired = TRUE, var.equal = FALSE, conf.level = 0.95)$conf.int[2][1], digits = 8)
#Activitat 11
var.test(GE$VelocProc_P, GE$VelocProc_B, ratio = 1, alternative = "two.sided", conf.level = 0.95)
print(t.test(GE$VelocProc_P, GE$VelocProc_B, mu = 0, alternative = "two.sided", paired = TRUE, var.equal = FALSE, conf.level = 0.95)$conf.int[1][1], digits = 8)
#Activitat 12
print(t.test(GE$VelocProc_P, GE$VelocProc_B, mu = 0, alternative = "two.sided", paired = TRUE, var.equal = FALSE, conf.level = 0.95)$conf.int[2][1], digits = 8)

#Activitat 13
print(t.test(GC$VelocProc_P, GC$VelocProc_B, mu = 0, alternative = "two.sided", paired = TRUE, var.equal = FALSE, conf.level = 0.95)$statistic, digits = 8)
#Activitat 14
print(t.test(GC$VelocProc_P, GC$VelocProc_B, mu = 0, alternative = "two.sided", paired = TRUE, var.equal = FALSE, conf.level = 0.95)$p.value, digits = 8)
#Activitat 15
print(t.test(GE$VelocProc_P, GE$VelocProc_B, mu = 0, alternative = "two.sided", paired = TRUE, var.equal = FALSE, conf.level = 0.95)$statistic, digits = 8)
#Activitat 16
print(t.test(GE$VelocProc_P, GE$VelocProc_B, mu = 0, alternative = "two.sided", paired = TRUE, var.equal = FALSE, conf.level = 0.95)$p.value, digits = 8)

#Activitat 17
dE <- GE$VelocProc_P - GE$VelocProc_B
dC <- GC$VelocProc_P - GC$VelocProc_B
var.test(dE, dC, ratio = 1, alternative = "two.sided", conf.level = 0.95)
print(t.test(dE, dC, mu = 0, alternative = "two.sided", paired = FALSE, var.equal = TRUE, conf.level = 0.95)$statistic, digits = 8)
#Activitat 18
print(t.test(dE, dC, mu = 0, alternative = "two.sided", paired = FALSE, var.equal = TRUE, conf.level = 0.95)$p.value, digits = 8)
