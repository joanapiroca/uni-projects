clear;
format long e;
format compact;

% Valors inicials.
a=9;
tol=1.e-6;
itmax=100;

figure(1);
clf(1);

% Valors als extrems de [8,10] de la derivada de les inverses de les
% funcions g1, g2 ,g3. 
fprintf('1/gp1(8)=%16.8e 1/gp1(8)=%16.8e \n',1/gp1(8), 1/gp1(10));
fprintf('1/gp2(8)=%16.8e 1/gp2(8)=%16.8e \n',1/gp2(8), 1/gp2(10));
fprintf('1/gp3(8)=%16.8e 1/gp3(8)=%16.8e \n',1/gp3(8), 1/gp3(10));

% Comprovació de que la inversa de g1 envia [8,10] dins [8,10].
fprintf('gi1(8)=%24.16e gi1(10)=%24.16e \n',gi1(8), gi1(10));
% Valor derivada g1i.
fprintf('gi1p(8)=%24.16e gi1p(10)=%24.16e \n',gi1p(8), gi1p(10));

L=abs(gi1p(10))

iter=ceil(log((1-L)*tol/2)/log(L));

fprintf('Nombre iteracions previstes=%4i\n\n',iter);

% Calculem primer la solució amb molta precissió.
tol2=1.e-14;
[xk1,res1,it1] = fixed_point_iter(a,tol2,itmax,@gi1);
fprintf("Calculem primer la solució amb molta precissió. \n");
fprintf('Solucio=%24.16e  Nombre iteracions=%3i \n\n',xk1(end), it1);
arrel=xk1(end);


[xk1,res1,it1] = fixed_point_iter(a,tol,itmax,@gi1);
fprintf('Solucio=%24.16e  Nombre iteracions=%3i \n',xk1(end), it1);
l1=size(xk1,2);
semilogy((0:l1-1),abs(xk1-arrel),'r-o');
xlabel('k');
ylabel('|x_k-\alpha|');

hold on;
[xk2,res2,it2] = fixed_point_iter(a,tol,itmax,@gi2);
fprintf('Solucio=%24.16e  Nombre iteracions=%3i \n',xk2(end), it2);
l2=size(xk2,2);
semilogy((0:l2-1),abs(xk2-arrel),'b-+');

[xk3,res3,it3] = fixed_point_iter(a,tol,itmax,@gi3);
fprintf('Solucio=%24.16e  Nombre iteracions=%3i \n',xk3(end), it3);
l3=size(xk3,2);
semilogy((0:l3-1),abs(xk3-arrel),'g-x');

sizes=[size(xk1,2),size(xk2,2),size(xk3,2)];
m=max(sizes);
semilogy((0:m-1),tol*ones(1,m),'k-');

pause;

l3=size(xk3,2);
xk3_ait(1:l3-2)=xk3(1:l3-2)-(xk3(2:l3-1)-xk3(1:l3-2)).^2./(xk3(3:l3)-2*xk3(2:l3-1)+xk3(1:l3-2));
semilogy((0:l3-3),abs(xk3_ait-xk1(end)),'r-*');

pause;

semilogy((0:l3-3),abs(xk3_ait-arrel),'b-*');

hold off;

function f = gi1(x)
 f = power(1000-x,1./3.);
end

function f = gi2(x)
 f = (-1+sqrt(1+4000*x))/2/x;
end

function f = gi3(x)
 f = sqrt(1000/x - 1);
end

function f = gp1(x)
 f = abs(3*x^2);
end

function f = gp2(x)
 f = abs((1-2000/x)/x^2);
end

function f = gp3(x)
 f = abs(2000*x/(1+x^2)^2);
end

function f = gi1p(x)
 f = -power(1000-x,-2./3.)/3;
end

